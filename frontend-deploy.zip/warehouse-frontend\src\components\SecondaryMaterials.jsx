import { Link, useNavigate } from 'react-router-dom'

function SecondaryMaterials() {
  const navigate = useNavigate()
  
  return (
    <div className="module-page">
      <div className="module-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <button 
            className="btn btn-secondary"
            onClick={() => navigate('/')}
            style={{ padding: '0.5rem 1rem' }}
          >
            ← Назад к панели
          </button>
          <h1 className="module-title" style={{ color: 'white' }}>Вторичное сырье</h1>
        </div>
        <button className="btn btn-primary">+ Добавить материал</button>
      </div>
      <div className="no-data"><p>Модуль вторичного сырья в разработке</p></div>
    </div>
  )
}

export default SecondaryMaterials