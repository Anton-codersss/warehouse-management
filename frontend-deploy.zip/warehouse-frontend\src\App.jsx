import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { Suspense, lazy, useState, useEffect } from 'react'
import Header from './components/Header'
import Login from './components/Login'
import PerformanceMonitor from './components/PerformanceMonitor'
import { authAPI } from './services/api'
import './App.css'

// Lazy load components for better performance
const Dashboard = lazy(() => import('./components/Dashboard'))
const Equipment = lazy(() => import('./components/Equipment'))
const Machinery = lazy(() => import('./components/Machinery'))
const PestControl = lazy(() => import('./components/PestControl'))
const EnergyResources = lazy(() => import('./components/EnergyResources'))
const Emergency = lazy(() => import('./components/Emergency'))
const Works = lazy(() => import('./components/Works'))
const Schemes = lazy(() => import('./components/Schemes'))
const Consumables = lazy(() => import('./components/Consumables'))
const SecondaryMaterials = lazy(() => import('./components/SecondaryMaterials'))

// Loading component
const LoadingSpinner = () => (
  <div className="loading-spinner">
    <div className="spinner"></div>
    <p>Загрузка модуля...</p>
  </div>
)

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Проверяем, есть ли сохраненный токен
    const token = localStorage.getItem('token')
    const savedUser = localStorage.getItem('user')
    
    if (token && savedUser) {
      // Проверяем действительность токена
      authAPI.verify()
        .then(response => {
          if (response.data.success) {
            setUser(JSON.parse(savedUser))
            setIsAuthenticated(true)
          } else {
            localStorage.removeItem('token')
            localStorage.removeItem('user')
          }
        })
        .catch(() => {
          localStorage.removeItem('token')
          localStorage.removeItem('user')
        })
        .finally(() => {
          setLoading(false)
        })
    } else {
      setLoading(false)
    }
  }, [])

  const handleLogin = (userData, token) => {
    setUser(userData)
    setIsAuthenticated(true)
  }

  const handleLogout = () => {
    localStorage.removeItem('token')
    localStorage.removeItem('user')
    setUser(null)
    setIsAuthenticated(false)
  }

  if (loading) {
    return (
      <div className="loading-spinner">
        <div className="spinner"></div>
        <p>Проверка авторизации...</p>
      </div>
    )
  }

  if (!isAuthenticated) {
    return <Login onLogin={handleLogin} />
  }
  return (
    <Router>
      <div className="app">
        <PerformanceMonitor />
        <Header user={user} onLogout={handleLogout} />
        <main className="main-content">
          <Suspense fallback={<LoadingSpinner />}>
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/equipment" element={<Equipment />} />
              <Route path="/machinery" element={<Machinery />} />
              <Route path="/pest-control" element={<PestControl />} />
              <Route path="/energy-resources" element={<EnergyResources />} />
              <Route path="/emergency" element={<Emergency />} />
              <Route path="/works" element={<Works />} />
              <Route path="/schemes" element={<Schemes />} />
              <Route path="/consumables" element={<Consumables />} />
              <Route path="/secondary-materials" element={<SecondaryMaterials />} />
            </Routes>
          </Suspense>
        </main>
      </div>
    </Router>
  )
}

export default App
