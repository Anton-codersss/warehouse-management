import React, { useState } from 'react'
import { authAPI } from '../services/api'

function Login({ onLogin }) {
  const [formData, setFormData] = useState({
    username: '',
    password: ''
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
    if (error) setError('')
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      const response = await authAPI.login(formData.username, formData.password)
      
      if (response.data.success) {
        // Сохраняем токен и данные пользователя
        localStorage.setItem('token', response.data.token)
        localStorage.setItem('user', JSON.stringify(response.data.user))
        
        // Вызываем callback для обновления состояния приложения
        onLogin(response.data.user, response.data.token)
      } else {
        setError(response.data.message || 'Ошибка входа в систему')
      }
    } catch (error) {
      console.error('Login error:', error)
      setError(
        error.response?.data?.message || 
        'Ошибка соединения с сервером'
      )
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="login-container">
      <div className="login-card">
        <div className="login-header">
          <h1>⚙️ СКЛАДСКОЙ КОМПЛЕКС</h1>
          <p>Система управления складским хозяйством</p>
        </div>
        
        <form onSubmit={handleSubmit} className="login-form">
          <div className="form-group">
            <label htmlFor="username">ЛОГИН</label>
            <input
              type="text"
              id="username"
              name="username"
              value={formData.username}
              onChange={handleChange}
              required
              disabled={loading}
              placeholder="Введите логин"
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="password">ПАРОЛЬ</label>
            <input
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              required
              disabled={loading}
              placeholder="Введите пароль"
            />
          </div>
          
          {error && (
            <div className="error-message">
              {error}
            </div>
          )}
          
          <button 
            type="submit" 
            className="btn btn-primary login-button"
            disabled={loading}
          >
            {loading ? 'ВХОД...' : 'ВОЙТИ В СИСТЕМУ'}
          </button>
        </form>
        
        <div className="login-help">
          <h4>ТЕСТОВЫЕ УЧЕТНЫЕ ЗАПИСИ:</h4>
          <div className="test-accounts">
            <div className="account">
              <strong>Администратор:</strong> admin / admin123
            </div>
            <div className="account">
              <strong>Оператор 1:</strong> operator1 / pass123
            </div>
            <div className="account">
              <strong>Оператор 2:</strong> operator2 / pass123
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Login