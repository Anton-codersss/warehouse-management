import React from 'react'
import { useNavigate } from 'react-router-dom'

function Dashboard() {
  const navigate = useNavigate()
  
  const modules = [
    {
      id: 'equipment',
      title: 'Складское Оборудование',
      description: 'Управление складским оборудованием, контроль состояния и техническое обслуживание',
      icon: '⚙️',
      path: '/equipment',
      className: 'equipment'
    },
    {
      id: 'machinery',
      title: 'Складская Техника',
      description: 'Учет и контроль складской техники, погрузчиков и транспортных средств',
      icon: '🚜',
      path: '/machinery',
      className: 'machinery'
    },
    {
      id: 'pest-control',
      title: 'ПЕСТ Контроль',
      description: 'Мониторинг и контроль вредителей, санитарно-гигиенические мероприятия',
      icon: '🛡️',
      path: '/pest-control',
      className: 'pest-control'
    },
    {
      id: 'energy',
      title: 'Энергоресурсы',
      description: 'Учет потребления электроэнергии, воды, газа и других энергоресурсов',
      icon: '🔌',
      path: '/energy-resources',
      className: 'energy'
    },
    {
      id: 'emergency',
      title: 'Аварийные ситуации',
      description: 'Регистрация и управление аварийными ситуациями и инцидентами',
      icon: '⚠️',
      path: '/emergency',
      className: 'emergency'
    },
    {
      id: 'works',
      title: 'Работы',
      description: 'Планирование и контроль выполнения работ по техническому обслуживанию',
      icon: '🔨',
      path: '/works',
      className: 'works'
    },
    {
      id: 'schemes',
      title: 'Схемы',
      description: 'Хранение и управление техническими схемами и чертежами склада',
      icon: '📐',
      path: '/schemes',
      className: 'schemes'
    },
    {
      id: 'consumables',
      title: 'Расходные материалы',
      description: 'Учет и контроль расходных материалов и их остатков',
      icon: '📋',
      path: '/consumables',
      className: 'consumables'
    },
    {
      id: 'secondary',
      title: 'Вторичное сырье',
      description: 'Управление вторичным сырьем и отходами производства',
      icon: '🔄',
      path: '/secondary-materials',
      className: 'secondary'
    }
  ]

  const navigateToModule = (module) => {
    navigate(module.path)
  }

  return (
    <div className="dashboard">
      <h1 className="dashboard-title">Панель управления складским комплексом</h1>
      <p style={{ textAlign: 'center', color: '#666', marginBottom: '2rem', fontSize: '1.1rem' }}>
        Выберите модуль для работы
      </p>
      
      <div className="dashboard-grid">
        {modules.map((module) => (
          <div
            key={module.id}
            onClick={() => navigateToModule(module)}
            className={`dashboard-card ${module.className}`}
            style={{ cursor: 'pointer' }}
          >
            <div className="icon">{module.icon}</div>
            <h3>{module.title}</h3>
            <p>{module.description}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

export default Dashboard