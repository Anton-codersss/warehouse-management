import React, { useState, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import FileUpload from './FileUpload'

function PestControl() {
  const navigate = useNavigate()
  const [activeSubSection, setActiveSubSection] = useState('overview')
  const [rodentLog, setRodentLog] = useState([])
  const [crawlingInsectLog, setCrawlingInsectLog] = useState([])
  const [flyingInsectLog, setFlyingInsectLog] = useState([])
  const [showAddForm, setShowAddForm] = useState(false)
  const [currentLogType, setCurrentLogType] = useState('')
  const [formData, setFormData] = useState({
    inspectionDate: '',
    controlPointNumber: '',
    tpkCondition: '',
    pestsFound: '',
    tpkActions: ''
  })

  useEffect(() => {
    // Initialize sample data for pest control logs
    setRodentLog([
      {
        id: 1,
        inspectionDate: '2024-12-01',
        controlPointNumber: 'ТПК-001',
        tpkCondition: 'Удовлетворительное',
        pestsFound: 'Не обнаружено',
        tpkActions: 'Замена приманки'
      },
      {
        id: 2,
        inspectionDate: '2024-11-28',
        controlPointNumber: 'ТПК-002',
        tpkCondition: 'Требует внимания',
        pestsFound: 'Следы активности',
        tpkActions: 'Замена ловушки'
      }
    ])

    setCrawlingInsectLog([
      {
        id: 1,
        inspectionDate: '2024-12-02',
        controlPointNumber: 'ТПК-003',
        tpkCondition: 'Хорошее',
        pestsFound: 'Не обнаружено',
        tpkActions: 'Замена клеевых листов'
      }
    ])

    setFlyingInsectLog([
      {
        id: 1,
        inspectionDate: '2024-12-03',
        controlPointNumber: 'ТПК-004',
        tpkCondition: 'Удовлетворительное',
        pestsFound: 'Единичные особи',
        tpkActions: 'Замена ловушки'
      }
    ])
  }, [])

  const subSections = [
    { id: 'overview', name: 'Обзор ПЕСТ контроля', icon: '🏠', description: 'Общая информация о программе ПЕСТ контроля' },
    { id: 'pest-program', name: 'Программа ПЕСТ контроля', icon: '📄', description: 'Документ программы ПЕСТ контроля' },
    { id: 'work-schedules', name: 'Графики работ и проверок', icon: '📅', description: 'Ежегодный график визитов и проверок' },
    { id: 'rodent-monitoring', name: 'Мониторинг грызунов', icon: '🐭', description: 'Журнал учета результатов мониторинга грызунов' },
    { id: 'crawling-insects', name: 'Мониторинг ползающих насекомых', icon: '🐛', description: 'Журнал мониторинга ползающих насекомых' },
    { id: 'flying-insects', name: 'Мониторинг летающих насекомых', icon: '🦟', description: 'Журнал мониторинга летающих насекомых' },
    { id: 'acts', name: 'Акты', icon: '📋', description: 'Акты обработки, визитов и замены оборудования' },
    { id: 'documentation', name: 'Документация', icon: '📚', description: 'Договоры, лицензии, схемы и сертификаты' }
  ]

  const handleFormChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmitLog = (e) => {
    e.preventDefault()
    const newEntry = {
      id: Date.now(),
      ...formData
    }

    if (currentLogType === 'rodent') {
      setRodentLog(prev => [...prev, newEntry])
    } else if (currentLogType === 'crawling') {
      setCrawlingInsectLog(prev => [...prev, newEntry])
    } else if (currentLogType === 'flying') {
      setFlyingInsectLog(prev => [...prev, newEntry])
    }

    setFormData({
      inspectionDate: '',
      controlPointNumber: '',
      tpkCondition: '',
      pestsFound: '',
      tpkActions: ''
    })
    setShowAddForm(false)
    setCurrentLogType('')
  }

  const openAddForm = (logType) => {
    setCurrentLogType(logType)
    setShowAddForm(true)
  }

  const renderSubSectionContent = () => {
    switch (activeSubSection) {
      case 'overview':
        return renderOverview()
      case 'pest-program':
        return renderPestProgram()
      case 'work-schedules':
        return renderWorkSchedules()
      case 'rodent-monitoring':
        return renderRodentMonitoring()
      case 'crawling-insects':
        return renderCrawlingInsects()
      case 'flying-insects':
        return renderFlyingInsects()
      case 'acts':
        return renderActs()
      case 'documentation':
        return renderDocumentation()
      default:
        return renderOverview()
    }
  }

  const renderOverview = () => {
    return (
      <div>
        <h3>Обзор системы ПЕСТ контроля</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '1rem', marginTop: '2rem' }}>
          <div className="dashboard-card" style={{ textAlign: 'center', padding: '2rem' }}>
            <h4>Активные точки контроля</h4>
            <p style={{ fontSize: '2rem', color: '#667eea', fontWeight: 'bold' }}>24</p>
          </div>
          <div className="dashboard-card" style={{ textAlign: 'center', padding: '2rem' }}>
            <h4>Последняя проверка</h4>
            <p style={{ fontSize: '1.2rem', color: '#666' }}>03.12.2024</p>
          </div>
          <div className="dashboard-card" style={{ textAlign: 'center', padding: '2rem' }}>
            <h4>Следующий визит</h4>
            <p style={{ fontSize: '1.2rem', color: '#e74c3c' }}>15.12.2024</p>
          </div>
          <div className="dashboard-card" style={{ textAlign: 'center', padding: '2rem' }}>
            <h4>Статус контроля</h4>
            <p style={{ fontSize: '1.2rem', color: '#27ae60' }}>Активен</p>
          </div>
        </div>
      </div>
    )
  }

  const renderPestProgram = () => {
    return (
      <div>
        <h3>Программа ПЕСТ контроля</h3>
        <div className="data-grid">
          <table>
            <thead>
              <tr>
                <th>Документ</th>
                <th>Версия</th>
                <th>Дата утверждения</th>
                <th>Статус</th>
                <th>Действия</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Программа ПЕСТ контроля 2024</td>
                <td>v1.2</td>
                <td>01.01.2024</td>
                <td><span className="status-badge status-active">Действующая</span></td>
                <td>
                  <button className="btn btn-primary" style={{ fontSize: '0.8rem' }}>Скачать</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    )
  }

  const renderWorkSchedules = () => {
    return (
      <div>
        <h3>Графики работ и проверок</h3>
        <div style={{ marginBottom: '2rem' }}>
          <h4>Ежегодный график визитов</h4>
        </div>
        <div className="data-grid">
          <table>
            <thead>
              <tr>
                <th>Месяц</th>
                <th>Плановая дата</th>
                <th>Тип визита</th>
                <th>Ответственный</th>
                <th>Статус</th>
                <th>Действия</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Декабрь 2024</td>
                <td>15.12.2024</td>
                <td>Плановый осмотр</td>
                <td>ООО "ПестСервис"</td>
                <td><span className="status-badge status-pending">Запланирован</span></td>
                <td>
                  <button className="btn btn-primary" style={{ fontSize: '0.8rem' }}>Подробно</button>
                </td>
              </tr>
              <tr>
                <td>Январь 2025</td>
                <td>15.01.2025</td>
                <td>Плановый осмотр</td>
                <td>ООО "ПестСервис"</td>
                <td><span className="status-badge status-pending">Запланирован</span></td>
                <td>
                  <button className="btn btn-primary" style={{ fontSize: '0.8rem' }}>Подробно</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    )
  }

  const renderMonitoringLog = (logData, logType, title) => {
    return (
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
          <h3>{title}</h3>
          <button 
            className="btn btn-primary"
            onClick={() => openAddForm(logType)}
          >
            + Добавить запись
          </button>
        </div>
        <div className="data-grid">
          <table>
            <thead>
              <tr>
                <th>Дата обследования</th>
                <th>Номер точки ПЕСТ контроля</th>
                <th>Состояние ТПК</th>
                <th>Обнаружено {logType === 'rodent' ? 'грызунов' : 'насекомых'}</th>
                <th>Действия с ТПК</th>
                <th>Действия</th>
              </tr>
            </thead>
            <tbody>
              {logData.map((entry) => (
                <tr key={entry.id}>
                  <td>{entry.inspectionDate ? new Date(entry.inspectionDate).toLocaleDateString('ru-RU') : '-'}</td>
                  <td>{entry.controlPointNumber}</td>
                  <td>
                    <span className={`status-badge ${
                      entry.tpkCondition === 'Хорошее' ? 'status-active' :
                      entry.tpkCondition === 'Удовлетворительное' ? 'status-pending' : 'status-inactive'
                    }`}>
                      {entry.tpkCondition}
                    </span>
                  </td>
                  <td>{entry.pestsFound}</td>
                  <td>{entry.tpkActions}</td>
                  <td>
                    <button className="btn btn-primary" style={{ fontSize: '0.8rem' }}>Редактировать</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    )
  }

  const renderRodentMonitoring = () => {
    return renderMonitoringLog(rodentLog, 'rodent', 'Журнал учета результатов мониторинга грызунов')
  }

  const renderCrawlingInsects = () => {
    return renderMonitoringLog(crawlingInsectLog, 'crawling', 'Журнал учета результатов мониторинга ползающих насекомых')
  }

  const renderFlyingInsects = () => {
    return renderMonitoringLog(flyingInsectLog, 'flying', 'Журнал учета результатов мониторинга летающих насекомых')
  }

  const renderActs = () => {
    return (
      <div>
        <h3>Акты</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1rem', marginTop: '2rem' }}>
          <div className="dashboard-card" style={{ textAlign: 'center', padding: '2rem' }}>
            <h4>Акты обработки помещений</h4>
            <p style={{ color: '#666', marginBottom: '1rem' }}>Документы о проведенных обработках</p>
            <button className="btn btn-primary">Просмотр актов</button>
          </div>
          <div className="dashboard-card" style={{ textAlign: 'center', padding: '2rem' }}>
            <h4>Акты по результатам визитов</h4>
            <p style={{ color: '#666', marginBottom: '1rem' }}>Отчеты о проведенных осмотрах</p>
            <button className="btn btn-primary">Просмотр актов</button>
          </div>
          <div className="dashboard-card" style={{ textAlign: 'center', padding: '2rem' }}>
            <h4>Акты замены инсектицидных ламп</h4>
            <p style={{ color: '#666', marginBottom: '1rem' }}>Документы о замене оборудования</p>
            <button className="btn btn-primary">Просмотр актов</button>
          </div>
        </div>
      </div>
    )
  }

  const renderDocumentation = () => {
    return (
      <div>
        <h3>Документация</h3>
        <div className="data-grid">
          <table>
            <thead>
              <tr>
                <th>Тип документа</th>
                <th>Название</th>
                <th>Дата</th>
                <th>Статус</th>
                <th>Действия</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Договор</td>
                <td>Договор на ПЕСТ контроль №123-2024</td>
                <td>01.01.2024</td>
                <td><span className="status-badge status-active">Действующий</span></td>
                <td>
                  <button className="btn btn-primary" style={{ fontSize: '0.8rem' }}>Скачать</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    )
  }

  return (
    <div className="module-page">
      <div className="module-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <button 
            className="btn btn-secondary"
            onClick={() => navigate('/')}
            style={{ padding: '0.5rem 1rem' }}
          >
            ← Назад к панели
          </button>
          <h1 className="module-title" style={{ color: 'white' }}>ПЕСТ Контроль</h1>
        </div>
        <div>
          <button className="btn btn-primary">+ Добавить запись</button>
        </div>
      </div>

      {/* Subsections Navigation */}
      <div style={{ marginBottom: '2rem' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1rem' }}>
          {subSections.map((subSection) => (
            <div
              key={subSection.id}
              onClick={() => setActiveSubSection(subSection.id)}
              className={`subsection-card ${
                activeSubSection === subSection.id ? 'active' : ''
              }`}
              style={{
                cursor: 'pointer',
                minHeight: '120px'
              }}
            >
              <div className="icon">{subSection.icon}</div>
              <h3 style={{ fontSize: '1rem' }}>{subSection.name}</h3>
              <p style={{ fontSize: '0.85rem' }}>{subSection.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Dynamic Content based on active subsection */}
      {renderSubSectionContent()}

      {/* Add Log Entry Form Modal */}
      {showAddForm && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '600px', width: '100%', maxHeight: '95vh' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
              <h2>Добавить запись в журнал мониторинга</h2>
              <button 
                onClick={() => setShowAddForm(false)}
                style={{ background: 'none', border: 'none', fontSize: '1.5rem', cursor: 'pointer', color: '#666' }}
              >
                ×
              </button>
            </div>
            
            <div style={{ overflowY: 'auto', flex: 1 }}>
              <form onSubmit={handleSubmitLog}>
                <div style={{ display: 'grid', gap: '1rem' }}>
                  <div className="form-group">
                    <label>Дата обследования</label>
                    <input
                      type="date"
                      name="inspectionDate"
                      value={formData.inspectionDate}
                      onChange={handleFormChange}
                      required
                    />
                  </div>
                  
                  <div className="form-group">
                    <label>Номер точки ПЕСТ контроля</label>
                    <input
                      type="text"
                      name="controlPointNumber"
                      value={formData.controlPointNumber}
                      onChange={handleFormChange}
                      placeholder="Например: ТПК-001"
                      required
                    />
                  </div>
                  
                  <div className="form-group">
                    <label>Состояние ТПК</label>
                    <select
                      name="tpkCondition"
                      value={formData.tpkCondition}
                      onChange={handleFormChange}
                      required
                    >
                      <option value="">Выберите состояние</option>
                      <option value="Хорошее">Хорошее</option>
                      <option value="Удовлетворительное">Удовлетворительное</option>
                      <option value="Требует внимания">Требует внимания</option>
                      <option value="Неудовлетворительное">Неудовлетворительное</option>
                    </select>
                  </div>
                  
                  <div className="form-group">
                    <label>Обнаружено {currentLogType === 'rodent' ? 'грызунов' : 'насекомых'}</label>
                    <select
                      name="pestsFound"
                      value={formData.pestsFound}
                      onChange={handleFormChange}
                      required
                    >
                      <option value="">Выберите результат</option>
                      <option value="Не обнаружено">Не обнаружено</option>
                      <option value="Единичные особи">Единичные особи</option>
                      <option value="Следы активности">Следы активности</option>
                      <option value="Множественные особи">Множественные особи</option>
                    </select>
                  </div>
                  
                  <div className="form-group">
                    <label>Действия с ТПК</label>
                    <select
                      name="tpkActions"
                      value={formData.tpkActions}
                      onChange={handleFormChange}
                      required
                    >
                      <option value="">Выберите действие</option>
                      {currentLogType === 'rodent' && (
                        <>
                          <option value="Замена приманки">Замена приманки</option>
                          <option value="Замена ловушки">Замена ловушки</option>
                          <option value="Замена клеевых листов">Замена клеевых листов</option>
                        </>
                      )}
                      {(currentLogType === 'crawling' || currentLogType === 'flying') && (
                        <>
                          <option value="Замена ловушки">Замена ловушки</option>
                          <option value="Замена клеевых листов">Замена клеевых листов</option>
                        </>
                      )}
                      <option value="Без изменений">Без изменений</option>
                    </select>
                  </div>
                </div>
                
                <div className="form-actions" style={{ marginTop: '2rem' }}>
                  <button 
                    type="button" 
                    className="btn btn-secondary"
                    onClick={() => setShowAddForm(false)}
                  >
                    Отмена
                  </button>
                  <button type="submit" className="btn btn-primary">
                    Добавить запись
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default PestControl