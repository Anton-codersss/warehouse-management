import { useState, useEffect, useMemo } from 'react'

export const useDebounce = (value, delay) => {
  const [debouncedValue, setDebouncedValue] = useState(value)

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value)
    }, delay)

    return () => {
      clearTimeout(handler)
    }
  }, [value, delay])

  return debouncedValue
}

export const useSearch = (items, searchTerm, searchFields = ['name'], delay = 300) => {
  const debouncedSearchTerm = useDebounce(searchTerm, delay)
  
  const filteredItems = useMemo(() => {
    if (!debouncedSearchTerm) return items
    
    return items.filter(item =>
      searchFields.some(field => {
        const fieldValue = item[field]
        return fieldValue && 
               fieldValue.toString().toLowerCase().includes(debouncedSearchTerm.toLowerCase())
      })
    )
  }, [items, debouncedSearchTerm, searchFields])
  
  return {
    filteredItems,
    isSearching: searchTerm !== debouncedSearchTerm,
    searchTerm: debouncedSearchTerm
  }
}