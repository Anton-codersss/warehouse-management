import React, { useState, useEffect, useCallback, useMemo } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { equipmentAPI } from '../services/api'
import FileUpload from './FileUpload'

function Equipment() {
  const navigate = useNavigate()
  const [equipment, setEquipment] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const [selectedEquipment, setSelectedEquipment] = useState(null)
  const [showModal, setShowModal] = useState(false)
  const [activeSubSection, setActiveSubSection] = useState('equipment-list')
  const [showAddForm, setShowAddForm] = useState(false)
  const [equipmentRegistry, setEquipmentRegistry] = useState([])
  
  // Maintenance log state
  const [maintenanceLog, setMaintenanceLog] = useState([])
  const [showAddMaintenanceForm, setShowAddMaintenanceForm] = useState(false)
  const [maintenanceFormData, setMaintenanceFormData] = useState({
    repairDate: '',
    inventoryNumber: '',
    equipmentType: '',
    customEquipmentType: '',
    equipmentName: '',
    workType: '',
    performedWork: '',
    manufacturer: '',
    model: '',
    installationLocation: '',
    manufacturingDate: '',
    commissioningDate: '',
    workWarranty: '',
    performingOrganization: '',
    cost: '',
    workActLink: ''
  })
  const [formData, setFormData] = useState({
    inventoryNumber: '',
    equipmentType: '',
    customEquipmentType: '',
    name: '',
    manufacturer: '',
    model: '',
    serialNumber: '',
    installationLocation: '',
    manufacturingDate: '',
    commissioningDate: '',
    technicalSpecs: '',
    regulatoryDocs: '',
    operatingInstructions: '',
    warranty: '',
    warrantyPeriod: ''
  })

  useEffect(() => {
    fetchEquipment()
    fetchMaintenanceLog()
    // Initialize equipment registry with sample data
    setEquipmentRegistry([
      {
        id: 1,
        inventoryNumber: 'INV-001',
        equipmentType: 'Климатическое',
        name: 'Кондиционер промышленный',
        manufacturer: 'Daikin',
        model: 'VRV-A',
        serialNumber: 'DK2024001',
        installationLocation: 'Зона А1',
        manufacturingDate: '2024-01-15',
        commissioningDate: '2024-02-01',
        technicalSpecs: 'Мощность 25 кВт, R410A',
        regulatoryDocs: 'ГОСТ 12.2.063-2015',
        operatingInstructions: 'Инструкция DK-VRV.pdf',
        warranty: 'Гарантия 3 года',
        warrantyPeriod: '3 года'
      },
      {
        id: 2,
        inventoryNumber: 'INV-002',
        equipmentType: 'Подъёмное оборудование',
        name: 'Подъёмник гидравлический',
        manufacturer: 'GENIE',
        model: 'GS-3246',
        serialNumber: 'GN2024002',
        installationLocation: 'Зона погрузки',
        manufacturingDate: '2024-02-10',
        commissioningDate: '2024-03-01',
        technicalSpecs: 'Грузоподъёмность 500 кг, высота подъёма 10 м',
        regulatoryDocs: 'ПБ 10-382-00',
        operatingInstructions: 'Инструкция GENIE-GS.pdf',
        warranty: 'Гарантия 2 года',
        warrantyPeriod: '2 года'
      }
    ])
  }, [])

  const fetchEquipment = useCallback(async () => {
    try {
      setLoading(true)
      const response = await equipmentAPI.getAll()
      setEquipment(response.data)
      setError(null)
    } catch (err) {
      setError('Ошибка при загрузке данных оборудования')
      console.error('Error fetching equipment:', err)
    } finally {
      setLoading(false)
    }
  }, [])

  const fetchMaintenanceLog = useCallback(async () => {
    try {
      const response = await equipmentAPI.getMaintenanceLog()
      setMaintenanceLog(response.data)
    } catch (err) {
      console.error('Error fetching maintenance log:', err)
      // Keep existing sample data if API fails
    }
  }, [])

  const equipmentTypes = useMemo(() => [
    'Климатическое',
    'Ворота',
    'Подъёмное оборудование',
    'Пресс',
    'Упаковочное оборудование',
    'Транспортное оборудование',
    'Конвейерное оборудование',
    'Освещение',
    'Охранное оборудование',
    'Пожарное оборудование',
    'Электрооборудование',
    'Свой вариант'
  ], [])

  const handleFormInputChange = useCallback((e) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }, [])

  const handleSubmitEquipment = useCallback((e) => {
    e.preventDefault()
    const newEquipment = {
      id: equipmentRegistry.length + 1,
      ...formData,
      equipmentType: formData.equipmentType === 'Свой вариант' ? formData.customEquipmentType : formData.equipmentType
    }
    setEquipmentRegistry(prev => [...prev, newEquipment])
    setFormData({
      inventoryNumber: '',
      equipmentType: '',
      customEquipmentType: '',
      name: '',
      manufacturer: '',
      model: '',
      serialNumber: '',
      installationLocation: '',
      manufacturingDate: '',
      commissioningDate: '',
      technicalSpecs: '',
      regulatoryDocs: '',
      operatingInstructions: '',
      warranty: '',
      warrantyPeriod: ''
    })
    setShowAddForm(false)
  }, [formData, equipmentRegistry.length])

  // Maintenance log handlers
  const handleMaintenanceFormChange = useCallback((e) => {
    const { name, value } = e.target
    setMaintenanceFormData(prev => ({ ...prev, [name]: value }))
  }, [])

  const handleSubmitMaintenance = useCallback(async (e) => {
    e.preventDefault()
    try {
      setLoading(true)
      const newEntry = {
        ...maintenanceFormData,
        equipmentType: maintenanceFormData.equipmentType === 'Свой вариант' ? maintenanceFormData.customEquipmentType : maintenanceFormData.equipmentType
      }
      
      const response = await equipmentAPI.createMaintenanceEntry(newEntry)
      
      // Add to local state
      setMaintenanceLog(prev => [response.data, ...prev])
      
      // Reset form
      setMaintenanceFormData({
        repairDate: '',
        inventoryNumber: '',
        equipmentType: '',
        customEquipmentType: '',
        equipmentName: '',
        workType: '',
        performedWork: '',
        manufacturer: '',
        model: '',
        installationLocation: '',
        manufacturingDate: '',
        commissioningDate: '',
        workWarranty: '',
        performingOrganization: '',
        cost: '',
        workActLink: ''
      })
      
      setShowAddMaintenanceForm(false)
      setError(null)
      
      console.log('Запись в журнал ТО успешно сохранена')
    } catch (err) {
      setError('Ошибка при сохранении записи в журнал ТО')
      console.error('Error saving maintenance entry:', err)
    } finally {
      setLoading(false)
    }
  }, [maintenanceFormData])




  const subSections = [
    { id: 'equipment-list', name: 'Стеллажное оборудование', icon: '건축️', description: 'Основной список оборудования' },
    { id: 'equipment-registry', name: 'Реестр оборудования', icon: '📋', description: 'Полный реестр оборудования с детальной информацией' },
    { id: 'maintenance-log', name: 'Журнал ТО и ремонтов оборудования', icon: '📝', description: 'История обслуживания и ремонтов' },
    { id: 'service-schedules', name: 'Графики обслуживания', icon: '📅', description: 'Планирование технического обслуживания' },
    { id: 'workers', name: 'Исполнители работ', icon: '👥', description: 'Специалисты по обслуживанию' },
    { id: 'documentation', name: 'Документация', icon: '📚', description: 'Техническая документация и инструкции' },
    { id: 'finances', name: 'Финансы', icon: '💰', description: 'Затраты на обслуживание и ремонт' }
  ]

  // Rack Equipment Subsections
  const rackSubSections = [
    { id: 'rack-passport', name: 'Паспортные данные стеллажей', icon: '📋', description: 'Технические паспорта стеллажного оборудования' },
    { id: 'rack-schemes', name: 'Схема стеллажей', icon: '📐', description: 'Схемы расположения и конструкции стеллажей' },
    { id: 'rack-documentation', name: 'Документация на стеллажи', icon: '📁', description: 'Техническая документация стеллажного оборудования' },
    { id: 'weekly-inspection', name: 'Журнал еженедельного осмотра стеллажей', icon: '📝', description: 'Еженедельные осмотры состояния стеллажей' },
    { id: 'certification-schedule', name: 'График аттестации и испытания стеллажей', icon: '📅', description: 'Планирование аттестации стеллажного оборудования' },
    { id: 'certification-contract', name: 'Договор на проведение аттестации и испытания стеллажей', icon: '📄', description: 'Договорная документация по аттестации' },
    { id: 'work-acts', name: 'Акты выполненных работ', icon: '✅', description: 'Документы о выполненных работах по стеллажам' },
    { id: 'defect-reports', name: 'Дефектные ведомости', icon: '⚠️', description: 'Ведомости выявленных дефектов стеллажей' }
  ]

  const handleViewDetails = (item) => {
    setSelectedEquipment(item)
    setShowModal(true)
  }

  // Render content based on active subsection
  const renderSubSectionContent = () => {
    switch (activeSubSection) {
      case 'equipment-list':
        return renderRackEquipmentSections()
      case 'equipment-registry':
        return renderEquipmentRegistry()
      case 'maintenance-log':
        return renderMaintenanceLog()
      case 'service-schedules':
        return <div className="no-data"><p>Графики обслуживания в разработке</p></div>
      case 'workers':
        return <div className="no-data"><p>Исполнители работ в разработке</p></div>
      case 'documentation':
        return <div className="no-data"><p>Документация в разработке</p></div>
      case 'finances':
        return <div className="no-data"><p>Финансы в разработке</p></div>
      // Rack Equipment Subsections
      case 'rack-passport':
        return renderRackPassportData()
      case 'rack-schemes':
        return renderRackSchemes()
      case 'rack-documentation':
        return renderRackDocumentation()
      case 'weekly-inspection':
        return renderWeeklyInspection()
      case 'certification-schedule':
        return renderCertificationSchedule()
      case 'certification-contract':
        return renderCertificationContract()
      case 'work-acts':
        return renderWorkActs()
      case 'defect-reports':
        return renderDefectReports()
      default:
        return renderRackEquipmentSections()
    }
  }

  const renderEquipmentList = () => {
    return (
      <div className="data-grid">
        {equipment.length === 0 ? (
          <div className="no-data">
            <p>Нет оборудования</p>
          </div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Название</th>
                <th>Тип</th>
                <th>Модель</th>
                <th>Статус</th>
                <th>Местоположение</th>
                <th>Следующее ТО</th>
                <th>Действия</th>
              </tr>
            </thead>
            <tbody>
              {equipment.map((item) => (
                <tr key={item.id}>
                  <td>{item.name}</td>
                  <td>{item.type}</td>
                  <td>{item.model || '-'}</td>
                  <td>{getStatusBadge(item.status)}</td>
                  <td>{item.location || '-'}</td>
                  <td>
                    {item.next_maintenance ? (
                      <span style={{
                        color: new Date(item.next_maintenance) - new Date() <= 30 * 24 * 60 * 60 * 1000 ? '#dc3545' : '#333'
                      }}>
                        {new Date(item.next_maintenance).toLocaleDateString('ru-RU')}
                      </span>
                    ) : '-'}
                  </td>
                  <td>
                    <button 
                      className="btn btn-primary" 
                      style={{ marginRight: '0.5rem', padding: '0.25rem 0.75rem', fontSize: '0.8rem' }}
                      onClick={() => handleViewDetails(item)}
                    >
                      Подробно
                    </button>
                    <button 
                      className="btn btn-warning" 
                      style={{ marginRight: '0.5rem', padding: '0.25rem 0.75rem', fontSize: '0.8rem' }}
                    >
                      Изменить
                    </button>
                    <button 
                      className="btn btn-danger" 
                      style={{ padding: '0.25rem 0.75rem', fontSize: '0.8rem' }}
                      onClick={() => handleDelete(item.id)}
                    >
                      Удалить
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    )
  }

  const renderMaintenanceLog = () => {
    return (
      <div>
        <div style={{ marginBottom: '2rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h3>Журнал ТО и ремонтов оборудования</h3>
          <button 
            className="btn btn-primary"
            onClick={() => setShowAddMaintenanceForm(true)}
          >
            + Добавить запись
          </button>
        </div>

        <div className="data-grid" style={{ overflowX: 'auto' }}>
          <table style={{ minWidth: '2200px' }}>
            <thead>
              <tr>
                <th style={{ minWidth: '60px' }}>№</th>
                <th style={{ minWidth: '100px' }}>Дата ремонта</th>
                <th style={{ minWidth: '120px' }}>Инвентарный номер</th>
                <th style={{ minWidth: '150px' }}>Тип оборудования</th>
                <th style={{ minWidth: '200px' }}>Название оборудования</th>
                <th style={{ minWidth: '100px' }}>Вид работ</th>
                <th style={{ minWidth: '250px' }}>Выполненные работы</th>
                <th style={{ minWidth: '120px' }}>Производитель</th>
                <th style={{ minWidth: '100px' }}>Модель</th>
                <th style={{ minWidth: '150px' }}>Место установки</th>
                <th style={{ minWidth: '120px' }}>Дата производства</th>
                <th style={{ minWidth: '130px' }}>Дата ввода в эксплуатацию</th>
                <th style={{ minWidth: '120px' }}>Гарантия на работы</th>
                <th style={{ minWidth: '180px' }}>Выполняющая организация</th>
                <th style={{ minWidth: '100px' }}>Стоимость</th>
                <th style={{ minWidth: '120px' }}>Ссылка на акт работ</th>
              </tr>
            </thead>
            <tbody>
              {maintenanceLog.map((item, index) => (
                <tr key={item.id}>
                  <td>{index + 1}</td>
                  <td>{item.repairDate ? new Date(item.repairDate).toLocaleDateString('ru-RU') : '-'}</td>
                  <td>{item.inventoryNumber}</td>
                  <td>{item.equipmentType}</td>
                  <td>{item.equipmentName}</td>
                  <td>{item.workType}</td>
                  <td style={{ maxWidth: '250px', overflow: 'hidden', textOverflow: 'ellipsis' }}>{item.performedWork || '-'}</td>
                  <td>{item.manufacturer}</td>
                  <td>{item.model}</td>
                  <td>{item.installationLocation}</td>
                  <td>{item.manufacturingDate ? new Date(item.manufacturingDate).toLocaleDateString('ru-RU') : '-'}</td>
                  <td>{item.commissioningDate ? new Date(item.commissioningDate).toLocaleDateString('ru-RU') : '-'}</td>
                  <td>{item.workWarranty || '-'}</td>
                  <td>{item.performingOrganization || '-'}</td>
                  <td>{item.cost ? `${item.cost} ₽` : '-'}</td>
                  <td>{item.workActLink || '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Add Maintenance Form Modal */}
        {showAddMaintenanceForm && (
          <div className="modal-overlay" style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0,0,0,0.5)',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            zIndex: 1000,
            padding: '1rem'
          }}>
            <div className="modal-content" style={{ 
              maxWidth: '900px', 
              width: '100%',
              maxHeight: '95vh', 
              backgroundColor: 'white',
              borderRadius: '8px',
              padding: '1.5rem',
              display: 'flex',
              flexDirection: 'column'
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem', flexShrink: 0 }}>
                <h2 style={{ margin: 0, fontSize: '1.25rem' }}>Добавить запись в журнал ТО и ремонтов</h2>
                <button 
                  onClick={() => setShowAddMaintenanceForm(false)}
                  style={{ background: 'none', border: 'none', fontSize: '1.5rem', cursor: 'pointer', color: '#666' }}
                >
                  ×
                </button>
              </div>
              
              <div style={{ overflowY: 'auto', flex: 1 }}>
                <form onSubmit={handleSubmitMaintenance}>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                    <div className="form-group">
                      <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Дата ремонта/ТО *</label>
                      <input
                        type="date"
                        name="repairDate"
                        value={maintenanceFormData.repairDate}
                        onChange={handleMaintenanceFormChange}
                        required
                        style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem' }}
                      />
                    </div>
                    
                    <div className="form-group">
                      <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Инвентарный номер *</label>
                      <input
                        type="text"
                        name="inventoryNumber"
                        value={maintenanceFormData.inventoryNumber}
                        onChange={handleMaintenanceFormChange}
                        required
                        style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem' }}
                      />
                    </div>
                    
                    <div className="form-group">
                      <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Тип оборудования *</label>
                      <select
                        name="equipmentType"
                        value={maintenanceFormData.equipmentType}
                        onChange={handleMaintenanceFormChange}
                        required
                        style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem' }}
                      >
                        <option value="">Выберите тип</option>
                        {equipmentTypes.map((type) => (
                          <option key={type} value={type}>{type}</option>
                        ))}
                      </select>
                    </div>
                    
                    {maintenanceFormData.equipmentType === 'Свой вариант' && (
                      <div className="form-group">
                        <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Укажите тип оборудования *</label>
                        <input
                          type="text"
                          name="customEquipmentType"
                          value={maintenanceFormData.customEquipmentType}
                          onChange={handleMaintenanceFormChange}
                          required
                          style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem' }}
                        />
                      </div>
                    )}
                    
                    <div className="form-group">
                      <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Название оборудования *</label>
                      <input
                        type="text"
                        name="equipmentName"
                        value={maintenanceFormData.equipmentName}
                        onChange={handleMaintenanceFormChange}
                        required
                        style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem' }}
                      />
                    </div>
                    
                    <div className="form-group">
                      <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Вид работ *</label>
                      <select
                        name="workType"
                        value={maintenanceFormData.workType}
                        onChange={handleMaintenanceFormChange}
                        required
                        style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem' }}
                      >
                        <option value="">Выберите вид работ</option>
                        <option value="ТО">Техническое обслуживание</option>
                        <option value="Ремонт">Ремонт</option>
                        <option value="Диагностика">Диагностика</option>
                        <option value="Замена">Замена компонентов</option>
                        <option value="Модернизация">Модернизация</option>
                        <option value="Профилактика">Профилактика</option>
                      </select>
                    </div>
                    
                    <div className="form-group">
                      <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Производитель</label>
                      <input
                        type="text"
                        name="manufacturer"
                        value={maintenanceFormData.manufacturer}
                        onChange={handleMaintenanceFormChange}
                        style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem' }}
                      />
                    </div>
                    
                    <div className="form-group">
                      <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Модель</label>
                      <input
                        type="text"
                        name="model"
                        value={maintenanceFormData.model}
                        onChange={handleMaintenanceFormChange}
                        style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem' }}
                      />
                    </div>
                    
                    <div className="form-group">
                      <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Место установки</label>
                      <input
                        type="text"
                        name="installationLocation"
                        value={maintenanceFormData.installationLocation}
                        onChange={handleMaintenanceFormChange}
                        style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem' }}
                      />
                    </div>
                    
                    <div className="form-group">
                      <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Дата производства</label>
                      <input
                        type="date"
                        name="manufacturingDate"
                        value={maintenanceFormData.manufacturingDate}
                        onChange={handleMaintenanceFormChange}
                        style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem' }}
                      />
                    </div>
                    
                    <div className="form-group">
                      <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Дата ввода в эксплуатацию</label>
                      <input
                        type="date"
                        name="commissioningDate"
                        value={maintenanceFormData.commissioningDate}
                        onChange={handleMaintenanceFormChange}
                        style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem' }}
                      />
                    </div>
                    
                    <div className="form-group">
                      <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Гарантия на работы</label>
                      <input
                        type="text"
                        name="workWarranty"
                        value={maintenanceFormData.workWarranty}
                        onChange={handleMaintenanceFormChange}
                        placeholder="например: 6 месяцев"
                        style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem' }}
                      />
                    </div>
                    
                    <div className="form-group">
                      <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Выполняющая организация</label>
                      <input
                        type="text"
                        name="performingOrganization"
                        value={maintenanceFormData.performingOrganization}
                        onChange={handleMaintenanceFormChange}
                        style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem' }}
                      />
                    </div>
                    
                    <div className="form-group">
                      <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Стоимость (₽)</label>
                      <input
                        type="number"
                        name="cost"
                        value={maintenanceFormData.cost}
                        onChange={handleMaintenanceFormChange}
                        min="0"
                        step="0.01"
                        style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem' }}
                      />
                    </div>
                    
                    <div className="form-group">
                      <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Ссылка на акт работ</label>
                      <input
                        type="text"
                        name="workActLink"
                        value={maintenanceFormData.workActLink}
                        onChange={handleMaintenanceFormChange}
                        placeholder="АКТ-2024-001"
                        style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem' }}
                      />
                    </div>
                    
                    <div className="form-group" style={{ gridColumn: '1 / -1' }}>
                      <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Выполненные работы *</label>
                      <textarea
                        name="performedWork"
                        value={maintenanceFormData.performedWork}
                        onChange={handleMaintenanceFormChange}
                        rows="3"
                        required
                        placeholder="Подробное описание выполненных работ..."
                        style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem', resize: 'vertical' }}
                      />
                    </div>
                  </div>
                  
                  <div className="form-actions" style={{ 
                    marginTop: '1.5rem', 
                    display: 'flex', 
                    justifyContent: 'flex-end', 
                    gap: '1rem',
                    paddingTop: '1rem',
                    borderTop: '1px solid #eee',
                    position: 'sticky',
                    bottom: 0,
                    backgroundColor: 'white'
                  }}>
                    <button 
                      type="button" 
                      className="btn btn-secondary"
                      onClick={() => setShowAddMaintenanceForm(false)}
                      style={{ padding: '0.6rem 1.2rem', fontSize: '0.9rem' }}
                    >
                      Отмена
                    </button>
                    <button 
                      type="submit" 
                      className="btn btn-primary"
                      style={{ padding: '0.6rem 1.2rem', fontSize: '0.9rem' }}
                    >
                      Добавить запись
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )}
      </div>
    )
  }

  const renderEquipmentRegistry = () => {
    return (
      <div>
        <div style={{ marginBottom: '2rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h3>Реестр оборудования</h3>
          <button 
            className="btn btn-primary"
            onClick={() => setShowAddForm(true)}
          >
            + Добавить оборудование
          </button>
        </div>

        <div className="data-grid" style={{ overflowX: 'auto' }}>
          <table style={{ minWidth: '1800px' }}>
            <thead>
              <tr>
                <th style={{ minWidth: '60px' }}>№</th>
                <th style={{ minWidth: '120px' }}>Инвентарный номер</th>
                <th style={{ minWidth: '150px' }}>Тип оборудования</th>
                <th style={{ minWidth: '200px' }}>Название</th>
                <th style={{ minWidth: '120px' }}>Производитель</th>
                <th style={{ minWidth: '100px' }}>Модель</th>
                <th style={{ minWidth: '120px' }}>Серийный номер</th>
                <th style={{ minWidth: '150px' }}>Место установки</th>
                <th style={{ minWidth: '120px' }}>Дата производства</th>
                <th style={{ minWidth: '130px' }}>Дата ввода в эксплуатацию</th>
                <th style={{ minWidth: '200px' }}>Технические характеристики</th>
                <th style={{ minWidth: '150px' }}>Нормативные документы</th>
                <th style={{ minWidth: '150px' }}>Инструкция по эксплуатации</th>
                <th style={{ minWidth: '120px' }}>Гарантия</th>
                <th style={{ minWidth: '100px' }}>Выполненные работы</th>
                <th style={{ minWidth: '100px' }}>Затраты</th>
                <th style={{ minWidth: '100px' }}>Срок гарантии</th>
              </tr>
            </thead>
            <tbody>
              {equipmentRegistry.map((item, index) => (
                <tr key={item.id}>
                  <td>{index + 1}</td>
                  <td>{item.inventoryNumber}</td>
                  <td>{item.equipmentType}</td>
                  <td>{item.name}</td>
                  <td>{item.manufacturer}</td>
                  <td>{item.model}</td>
                  <td>{item.serialNumber}</td>
                  <td>{item.installationLocation}</td>
                  <td>{item.manufacturingDate ? new Date(item.manufacturingDate).toLocaleDateString('ru-RU') : '-'}</td>
                  <td>{item.commissioningDate ? new Date(item.commissioningDate).toLocaleDateString('ru-RU') : '-'}</td>
                  <td style={{ maxWidth: '200px', overflow: 'hidden', textOverflow: 'ellipsis' }}>{item.technicalSpecs || '-'}</td>
                  <td>{item.regulatoryDocs || '-'}</td>
                  <td>{item.operatingInstructions || '-'}</td>
                  <td>{item.warranty || '-'}</td>
                  <td>
                    <button className="btn btn-secondary" style={{ padding: '0.25rem 0.5rem', fontSize: '0.8rem' }}>
                      Просмотр
                    </button>
                  </td>
                  <td>
                    <button className="btn btn-secondary" style={{ padding: '0.25rem 0.5rem', fontSize: '0.8rem' }}>
                      Просмотр
                    </button>
                  </td>
                  <td>{item.warrantyPeriod || '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {/* Add Equipment Form Modal */}
        {showAddForm && (
          <div className="modal-overlay" style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0,0,0,0.5)',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            zIndex: 1000,
            padding: '1rem'
          }}>
            <div className="modal-content" style={{ 
              maxWidth: '900px', 
              width: '100%',
              maxHeight: '90vh', 
              backgroundColor: 'white',
              borderRadius: '6px',
              border: '3px solid #2c3e50',
              display: 'flex',
              flexDirection: 'column',
              overflow: 'hidden'
            }}>
              <div style={{ 
                display: 'flex', 
                justifyContent: 'space-between', 
                alignItems: 'center', 
                padding: '1.5rem 1.5rem 1rem',
                borderBottom: '3px solid #2c3e50',
                flexShrink: 0,
                backgroundColor: 'white'
              }}>
                <h2 style={{ 
                  margin: 0, 
                  fontSize: '1.1rem',
                  color: '#2c3e50',
                  fontWeight: '700',
                  textTransform: 'uppercase',
                  letterSpacing: '1px'
                }}>Добавить оборудование</h2>
                <button 
                  onClick={() => setShowAddForm(false)}
                  style={{ 
                    background: 'none', 
                    border: 'none', 
                    fontSize: '1.5rem', 
                    cursor: 'pointer', 
                    color: '#666',
                    padding: '0',
                    width: '30px',
                    height: '30px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}
                >
                  ×
                </button>
              </div>
              
              <div style={{ 
                flex: 1, 
                overflowY: 'auto',
                padding: '1.5rem',
                display: 'flex',
                flexDirection: 'column'
              }}>
                <form onSubmit={handleSubmitEquipment} style={{ 
                  display: 'flex',
                  flexDirection: 'column',
                  height: '100%'
                }}>
                  <div style={{ 
                    flex: 1,
                    overflowY: 'auto',
                    paddingRight: '0.5rem',
                    marginRight: '-0.5rem'
                  }}>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                      <div className="form-group">
                        <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Инвентарный номер</label>
                        <input
                          type="text"
                          name="inventoryNumber"
                          value={formData.inventoryNumber}
                          onChange={handleFormInputChange}
                          required
                          style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem' }}
                        />
                      </div>
                    
                      <div className="form-group">
                        <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Тип оборудования</label>
                        <select
                          name="equipmentType"
                          value={formData.equipmentType}
                          onChange={handleFormInputChange}
                          required
                          style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem' }}
                        >
                          <option value="">Выберите тип</option>
                          {equipmentTypes.map((type) => (
                            <option key={type} value={type}>{type}</option>
                          ))}
                        </select>
                      </div>
                    
                      {formData.equipmentType === 'Свой вариант' && (
                        <div className="form-group">
                          <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Укажите тип оборудования</label>
                          <input
                            type="text"
                            name="customEquipmentType"
                            value={formData.customEquipmentType}
                            onChange={handleFormInputChange}
                            required
                            style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem' }}
                          />
                        </div>
                      )}
                    
                      <div className="form-group">
                        <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Название оборудования</label>
                        <input
                          type="text"
                          name="name"
                          value={formData.name}
                          onChange={handleFormInputChange}
                          required
                          style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem' }}
                        />
                      </div>
                    
                      <div className="form-group">
                        <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Производитель</label>
                        <input
                          type="text"
                          name="manufacturer"
                          value={formData.manufacturer}
                          onChange={handleFormInputChange}
                          style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem' }}
                        />
                      </div>
                    
                      <div className="form-group">
                        <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Модель</label>
                        <input
                          type="text"
                          name="model"
                          value={formData.model}
                          onChange={handleFormInputChange}
                          style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem' }}
                        />
                      </div>
                    
                      <div className="form-group">
                        <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Серийный номер</label>
                        <input
                          type="text"
                          name="serialNumber"
                          value={formData.serialNumber}
                          onChange={handleFormInputChange}
                          style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem' }}
                        />
                      </div>
                    
                      <div className="form-group">
                        <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Место установки</label>
                        <input
                          type="text"
                          name="installationLocation"
                          value={formData.installationLocation}
                          onChange={handleFormInputChange}
                          style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem' }}
                        />
                      </div>
                    
                      <div className="form-group">
                        <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Дата производства</label>
                        <input
                          type="date"
                          name="manufacturingDate"
                          value={formData.manufacturingDate}
                          onChange={handleFormInputChange}
                          style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem' }}
                        />
                      </div>
                    
                      <div className="form-group">
                        <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Дата ввода в эксплуатацию</label>
                        <input
                          type="date"
                          name="commissioningDate"
                          value={formData.commissioningDate}
                          onChange={handleFormInputChange}
                          style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem' }}
                        />
                      </div>
                    
                      <div className="form-group" style={{ gridColumn: '1 / -1' }}>
                        <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Технические характеристики</label>
                        <textarea
                          name="technicalSpecs"
                          value={formData.technicalSpecs}
                          onChange={handleFormInputChange}
                          rows="2"
                          style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem', resize: 'vertical' }}
                        />
                      </div>
                    
                      <div className="form-group">
                        <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Нормативные документы</label>
                        <input
                          type="text"
                          name="regulatoryDocs"
                          value={formData.regulatoryDocs}
                          onChange={handleFormInputChange}
                          style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem' }}
                        />
                      </div>
                    
                      <div className="form-group">
                        <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Инструкция по эксплуатации</label>
                        <input
                          type="text"
                          name="operatingInstructions"
                          value={formData.operatingInstructions}
                          onChange={handleFormInputChange}
                          style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem' }}
                        />
                      </div>
                    
                      <div className="form-group">
                        <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Гарантия</label>
                        <input
                          type="text"
                          name="warranty"
                          value={formData.warranty}
                          onChange={handleFormInputChange}
                          style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem' }}
                        />
                      </div>
                    
                      <div className="form-group">
                        <label style={{ fontSize: '0.9rem', fontWeight: '500', marginBottom: '0.25rem', display: 'block' }}>Срок гарантии</label>
                        <input
                          type="text"
                          name="warrantyPeriod"
                          value={formData.warrantyPeriod}
                          onChange={handleFormInputChange}
                          style={{ width: '100%', padding: '0.5rem', fontSize: '0.9rem' }}
                        />
                      </div>
                    </div>
                  </div>
                  
                  {/* File Upload Section - сокращенная версия */}
                  <div style={{ marginTop: '1rem', marginBottom: '1rem' }}>
                    <h4 style={{ marginBottom: '0.5rem', color: '#333', fontSize: '1rem' }}>Документы и файлы</h4>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                      <div>
                        <label style={{ display: 'block', marginBottom: '0.25rem', fontSize: '0.85rem', fontWeight: '500' }}>Паспорт оборудования</label>
                        <FileUpload 
                          onFileSelect={(files) => setFormData(prev => ({ ...prev, passportFiles: files }))}
                          multiple={true}
                          acceptedTypes=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                          maxSize={10}
                          label="Прикрепить паспорт"
                        />
                      </div>
                      
                      <div>
                        <label style={{ display: 'block', marginBottom: '0.25rem', fontSize: '0.85rem', fontWeight: '500' }}>Инструкции</label>
                        <FileUpload 
                          onFileSelect={(files) => setFormData(prev => ({ ...prev, instructionFiles: files }))}
                          multiple={true}
                          acceptedTypes=".pdf,.doc,.docx"
                          maxSize={10}
                          label="Прикрепить инструкции"
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div className="form-actions" style={{ 
                    marginTop: '1.5rem', 
                    display: 'flex', 
                    justifyContent: 'flex-end', 
                    gap: '1rem',
                    paddingTop: '1rem',
                    borderTop: '3px solid #2c3e50',
                    position: 'sticky',
                    bottom: 0,
                    backgroundColor: 'white',
                    flexShrink: 0
                  }}>
                    <button 
                      type="button" 
                      className="btn btn-secondary"
                      onClick={() => setShowAddForm(false)}
                      style={{ padding: '0.6rem 1.2rem', fontSize: '0.9rem' }}
                    >
                      Отмена
                    </button>
                    <button 
                      type="submit" 
                      className="btn btn-primary"
                      style={{ padding: '0.6rem 1.2rem', fontSize: '0.9rem' }}
                    >
                      Добавить оборудование
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )}
      </div>
    )
  }

  // Render Rack Equipment Sections Navigation
  const renderRackEquipmentSections = () => {
    return (
      <div>
        <div style={{ marginBottom: '2rem' }}>
          <h3>Стеллажное оборудование - Разделы</h3>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1rem', marginBottom: '2rem' }}>
          {rackSubSections.map((section) => (
            <div
              key={section.id}
              onClick={() => setActiveSubSection(section.id)}
              className="dashboard-card equipment"
              style={{ cursor: 'pointer', minHeight: '120px' }}
            >
              <div className="icon">{section.icon}</div>
              <h4 style={{ fontSize: '1rem', margin: '0.5rem 0' }}>{section.name}</h4>
              <p style={{ fontSize: '0.85rem', color: '#666' }}>{section.description}</p>
            </div>
          ))}
        </div>
        

        
        {renderEquipmentList()}
      </div>
    )
  }

  // Generic section renderer for rack subsections
  const renderRackSection = (title, sectionId, tableHeaders, tableData) => {
    return (
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
          <h3>{title}</h3>
          <button className="btn btn-secondary" onClick={() => setActiveSubSection('equipment-list')}>← Назад к разделам</button>
        </div>
        <div className="data-grid">
          <table>
            <thead>
              <tr>
                {tableHeaders.map((header, index) => <th key={index}>{header}</th>)}
              </tr>
            </thead>
            <tbody>
              {tableData.map((row, index) => (
                <tr key={index}>
                  {row.map((cell, cellIndex) => <td key={cellIndex}>{cell}</td>)}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    )
  }

  const renderRackPassportData = () => renderRackSection(
    'Паспортные данные стеллажей',
    'rack-passport',
    ['№ стеллажа', 'Модель', 'Производитель', 'Год выпуска', 'Грузоподъемность', 'Количество ярусов', 'Статус', 'Действия'],
    [['ST-001', 'MetalPro 2000', 'MetalSystems', '2023', '2000 кг', '5', <span className="status-badge status-active">Активный</span>, <button className="btn btn-primary" style={{fontSize: '0.8rem'}}>Подробно</button>]]
  )

  const renderRackSchemes = () => renderRackSection(
    'Схема стеллажей', 
    'rack-schemes',
    ['Тип схемы', 'Название', 'Дата создания', 'Статус', 'Действия'],
    [['Общая схема', 'План размещения стеллажей', '15.01.2023', <span className="status-badge status-active">Актуальная</span>, <button className="btn btn-primary" style={{fontSize: '0.8rem'}}>Скачать</button>]]
  )

  const renderRackDocumentation = () => renderRackSection(
    'Документация на стеллажи',
    'rack-documentation', 
    ['Тип документа', 'Название', 'Номер стеллажа', 'Дата создания', 'Статус', 'Действия'],
    [['Паспорт', 'Паспорт стеллажа MetalPro 2000', 'ST-001', '15.01.2023', <span className="status-badge status-active">Актуальный</span>, <button className="btn btn-primary" style={{fontSize: '0.8rem'}}>Скачать</button>]]
  )

  const renderWeeklyInspection = () => renderRackSection(
    'Журнал еженедельного осмотра стеллажей',
    'weekly-inspection',
    ['Неделя', 'Номер стеллажа', 'Дата осмотра', 'Ответственный', 'Состояние', 'Обнаруженные дефекты', 'Принятые меры', 'Действия'],
    [['2024-Н50', 'ST-001', '12.12.2024', 'Иванов И.И.', <span className="status-badge status-active">Хорошее</span>, '-', '-', <button className="btn btn-primary" style={{fontSize: '0.8rem'}}>Подробно</button>]]
  )

  const renderCertificationSchedule = () => renderRackSection(
    'График аттестации и испытания стеллажей',
    'certification-schedule',
    ['Номер стеллажа', 'Тип мероприятия', 'Плановая дата', 'Организация-исполнитель', 'Периодичность', 'Статус', 'Действия'],
    [['ST-001', 'Аттестация', '15.03.2025', 'ООО "Промэксперт"', '1 раз в год', <span className="status-badge status-pending">Запланировано</span>, <button className="btn btn-primary" style={{fontSize: '0.8rem'}}>Подробно</button>]]
  )

  const renderCertificationContract = () => renderRackSection(
    'Договор на проведение аттестации и испытания стеллажей',
    'certification-contract',
    ['Номер договора', 'Контрагент', 'Дата заключения', 'Срок действия', 'Сумма', 'Статус', 'Действия'],
    [['Д-2024-001', 'ООО "Промэксперт"', '01.01.2024', '31.12.2024', '150 000 ₽', <span className="status-badge status-active">Действует</span>, <button className="btn btn-primary" style={{fontSize: '0.8rem'}}>Скачать</button>]]
  )

  const renderWorkActs = () => renderRackSection(
    'Акты выполненных работ',
    'work-acts',
    ['Номер акта', 'Тип работ', 'Номер стеллажа', 'Дата выполнения', 'Исполнитель', 'Сумма', 'Статус', 'Действия'],
    [['АКТ-2024-001', 'Техническое обслуживание', 'ST-001', '15.11.2024', 'ООО "СервисТех"', '25 000 ₽', <span className="status-badge status-active">Выполнено</span>, <button className="btn btn-primary" style={{fontSize: '0.8rem'}}>Скачать</button>]]
  )

  const renderDefectReports = () => renderRackSection(
    'Дефектные ведомости',
    'defect-reports',
    ['Номер ведомости', 'Номер стеллажа', 'Дата обнаружения', 'Тип дефекта', 'Критичность', 'Ответственный', 'Статус', 'Действия'],
    [['ДВ-2024-001', 'ST-002', '05.12.2024', 'Повреждение краски', 'Низкая', 'Петров П.П.', <span className="status-badge status-pending">В работе</span>, <button className="btn btn-primary" style={{fontSize: '0.8rem'}}>Подробно</button>]]
  )

  const handleDelete = async (id) => {
    if (window.confirm('Вы уверены, что хотите удалить это оборудование?')) {
      try {
        await equipmentAPI.delete(id)
        setEquipment(equipment.filter(item => item.id !== id))
      } catch (err) {
        setError('Ошибка при удалении оборудования')
      }
    }
  }

  const getStatusBadge = (status) => {
    const statusClass = {
      'active': 'status-active',
      'inactive': 'status-inactive',
      'maintenance': 'status-pending'
    }[status] || 'status-pending'
    
    const statusText = {
      'active': 'Активно',
      'inactive': 'Неактивно',
      'maintenance': 'Обслуживание'
    }[status] || status
    
    return <span className={`status-badge ${statusClass}`}>{statusText}</span>
  }

  if (loading) return <div className="loading">Загрузка данных...</div>

  return (
    <div className="module-page">
      <div className="module-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <button 
            className="btn btn-secondary"
            onClick={() => navigate('/')}
            style={{ padding: '0.5rem 1rem' }}
          >
            ← Назад к панели
          </button>
          <h1 className="module-title" style={{ color: 'white' }}>Складское Оборудование</h1>
        </div>
        <div>
          <button className="btn btn-primary">+ Добавить оборудование</button>
        </div>
      </div>

      {/* Main Subsections Navigation */}
      <div style={{ marginBottom: '2rem' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1rem' }}>
          {subSections.map((subSection) => (
            <div
              key={subSection.id}
              onClick={() => setActiveSubSection(subSection.id)}
              className={`subsection-card ${
                activeSubSection === subSection.id ? 'active' : ''
              }`}
              style={{
                cursor: 'pointer',
                minHeight: '120px',
                border: activeSubSection === subSection.id ? '2px solid #667eea' : '2px solid transparent'
              }}
            >
              <div className="icon">{subSection.icon}</div>
              <h3 style={{ fontSize: '1.1rem' }}>{subSection.name}</h3>
              <p style={{ fontSize: '0.85rem' }}>{subSection.description}</p>
            </div>
          ))}
        </div>
      </div>



      {error && <div className="error">{error}</div>}

      {/* Dynamic Content based on active subsection */}
      {renderSubSectionContent()}

      {/* Equipment Details Modal */}
      {showModal && selectedEquipment && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0,0,0,0.5)',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          zIndex: 1000
        }}>
          <div style={{
            backgroundColor: 'white',
            padding: '2rem',
            borderRadius: '12px',
            maxWidth: '600px',
            width: '90%',
            maxHeight: '80vh',
            overflow: 'auto'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
              <h2>Подробная информация</h2>
              <button 
                onClick={() => setShowModal(false)}
                style={{
                  background: 'none',
                  border: 'none',
                  fontSize: '1.5rem',
                  cursor: 'pointer',
                  color: '#666'
                }}
              >
                ×
              </button>
            </div>
            
            <div style={{ display: 'grid', gap: '1rem' }}>
              <div>
                <strong>Название:</strong> {selectedEquipment.name}
              </div>
              <div>
                <strong>Тип:</strong> {selectedEquipment.type}
              </div>
              <div>
                <strong>Модель:</strong> {selectedEquipment.model || 'Не указана'}
              </div>
              <div>
                <strong>Серийный номер:</strong> {selectedEquipment.serial_number || 'Не указан'}
              </div>
              <div>
                <strong>Статус:</strong> {getStatusBadge(selectedEquipment.status)}
              </div>
              <div>
                <strong>Местоположение:</strong> {selectedEquipment.location || 'Не указано'}
              </div>
              <div>
                <strong>Последнее ТО:</strong> {selectedEquipment.maintenance_date ? new Date(selectedEquipment.maintenance_date).toLocaleDateString('ru-RU') : 'Не указано'}
              </div>
              <div>
                <strong>Следующее ТО:</strong> {selectedEquipment.next_maintenance ? new Date(selectedEquipment.next_maintenance).toLocaleDateString('ru-RU') : 'Не запланировано'}
              </div>
              <div>
                <strong>Описание:</strong> {selectedEquipment.description || 'Описание отсутствует'}
              </div>
              <div>
                <strong>Дата создания:</strong> {new Date(selectedEquipment.created_at).toLocaleDateString('ru-RU')}
              </div>
            </div>
            
            <div style={{ marginTop: '2rem', textAlign: 'right' }}>
              <button 
                className="btn btn-secondary"
                onClick={() => setShowModal(false)}
              >
                Закрыть
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default Equipment