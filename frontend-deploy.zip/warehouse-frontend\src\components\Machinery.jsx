import React, { useState, useEffect, useCallback } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { machineryAPI } from '../services/api'
import FileUpload from './FileUpload'

function Machinery() {
  const navigate = useNavigate()
  const [machinery, setMachinery] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [activeSubSection, setActiveSubSection] = useState('machinery-list')
  const [maintenanceLog, setMaintenanceLog] = useState([])
  const [showAddMaintenanceForm, setShowAddMaintenanceForm] = useState(false)
  const [maintenanceFormData, setMaintenanceFormData] = useState({
    repairDate: '',
    inventoryNumber: '',
    equipmentType: '',
    customEquipmentType: '',
    equipmentName: '',
    workType: '',
    performedWork: '',
    manufacturer: '',
    model: '',
    installationLocation: '',
    manufacturingDate: '',
    commissioningDate: '',
    workWarranty: '',
    performingOrganization: '',
    cost: '',
    workActLink: ''
  })

  useEffect(() => {
    fetchMachinery()
    // Initialize maintenance log with sample data
    setMaintenanceLog([
      {
        id: 1,
        repairDate: '2024-12-01',
        inventoryNumber: 'INV-001',
        equipmentType: 'Подъёмное оборудование',
        equipmentName: 'Подъёмник гидравлический',
        workType: 'ТО',
        performedWork: 'Замена масла, проверка гидравлики',
        manufacturer: 'GENIE',
        model: 'GS-3246',
        installationLocation: 'Зона погрузки',
        manufacturingDate: '2024-02-10',
        commissioningDate: '2024-03-01',
        workWarranty: '6 месяцев',
        performingOrganization: 'ООО "СервисТех"',
        cost: '15000',
        workActLink: 'АКТ-2024-001'
      },
      {
        id: 2,
        repairDate: '2024-11-15',
        inventoryNumber: 'INV-002',
        equipmentType: 'Климатическое',
        equipmentName: 'Кондиционер промышленный',
        workType: 'Ремонт',
        performedWork: 'Замена компрессора, заправка фреона',
        manufacturer: 'Daikin',
        model: 'VRV-A',
        installationLocation: 'Зона А1',
        manufacturingDate: '2024-01-15',
        commissioningDate: '2024-02-01',
        workWarranty: '12 месяцев',
        performingOrganization: 'ООО "КлиматСервис"',
        cost: '45000',
        workActLink: 'АКТ-2024-002'
      }
    ])
  }, [])

  const fetchMachinery = useCallback(async () => {
    try {
      setLoading(true)
      const response = await machineryAPI.getAll()
      setMachinery(response.data)
      setError(null)
    } catch (err) {
      setError('Ошибка при загрузке данных техники')
      console.error('Error fetching machinery:', err)
    } finally {
      setLoading(false)
    }
  }, [])

  const equipmentTypes = [
    'Климатическое',
    'Ворота',
    'Подъёмное оборудование',
    'Пресс',
    'Упаковочное оборудование',
    'Транспортное оборудование',
    'Конвейерное оборудование',
    'Освещение',
    'Охранное оборудование',
    'Пожарное оборудование',
    'Электрооборудование',
    'Свой вариант'
  ]

  const subSections = [
    { id: 'machinery-list', name: 'Список техники', icon: '🚜', description: 'Основной список складской техники' },
    { id: 'maintenance-log', name: 'Журнал ТО и ремонтов складской техники', icon: '📝', description: 'Журнал технического обслуживания и ремонтов складской техники' }
  ]

  const handleMaintenanceFormChange = (e) => {
    const { name, value } = e.target
    setMaintenanceFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmitMaintenance = (e) => {
    e.preventDefault()
    const newEntry = {
      id: maintenanceLog.length + 1,
      ...maintenanceFormData,
      equipmentType: maintenanceFormData.equipmentType === 'Свой вариант' ? maintenanceFormData.customEquipmentType : maintenanceFormData.equipmentType
    }
    setMaintenanceLog(prev => [...prev, newEntry])
    setMaintenanceFormData({
      repairDate: '',
      inventoryNumber: '',
      equipmentType: '',
      customEquipmentType: '',
      equipmentName: '',
      workType: '',
      performedWork: '',
      manufacturer: '',
      model: '',
      installationLocation: '',
      manufacturingDate: '',
      commissioningDate: '',
      workWarranty: '',
      performingOrganization: '',
      cost: '',
      workActLink: ''
    })
    setShowAddMaintenanceForm(false)
  }

  const renderSubSectionContent = () => {
    switch (activeSubSection) {
      case 'machinery-list':
        return renderMachineryList()
      case 'maintenance-log':
        return renderMaintenanceLog()
      default:
        return renderMachineryList()
    }
  }

  const renderMachineryList = () => {
    return (
      <div className="data-grid">
        {machinery.length === 0 ? (
          <div className="no-data">
            <p>Нет данных о технике</p>
          </div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Название</th>
                <th>Тип</th>
                <th>Бренд</th>
                <th>Модель</th>
                <th>Статус</th>
                <th>Местоположение</th>
              </tr>
            </thead>
            <tbody>
              {machinery.map((item) => (
                <tr key={item.id}>
                  <td>{item.name}</td>
                  <td>{item.type}</td>
                  <td>{item.brand || '-'}</td>
                  <td>{item.model || '-'}</td>
                  <td><span className="status-badge status-active">{item.status}</span></td>
                  <td>{item.location || '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    )
  }

  const renderMaintenanceLog = () => {
    return (
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
          <h3>Журнал ТО и ремонтов складской техники</h3>
          <button 
            className="btn btn-primary"
            onClick={() => setShowAddMaintenanceForm(true)}
          >
            + Добавить запись
          </button>
        </div>

        <div className="data-grid" style={{ overflowX: 'auto' }}>
          <table style={{ minWidth: '2000px' }}>
            <thead>
              <tr>
                <th style={{ minWidth: '60px' }}>№</th>
                <th style={{ minWidth: '120px' }}>Дата ремонта/ТО</th>
                <th style={{ minWidth: '120px' }}>Инвентарный номер</th>
                <th style={{ minWidth: '150px' }}>Тип оборудования</th>
                <th style={{ minWidth: '200px' }}>Название оборудования</th>
                <th style={{ minWidth: '100px' }}>Вид работ</th>
                <th style={{ minWidth: '200px' }}>Выполненные работы</th>
                <th style={{ minWidth: '120px' }}>Производитель</th>
                <th style={{ minWidth: '100px' }}>Модель</th>
                <th style={{ minWidth: '150px' }}>Место установки</th>
                <th style={{ minWidth: '120px' }}>Дата производства</th>
                <th style={{ minWidth: '130px' }}>Дата ввода в эксплуатацию</th>
                <th style={{ minWidth: '120px' }}>Гарантия на работы</th>
                <th style={{ minWidth: '180px' }}>Организация-исполнитель</th>
                <th style={{ minWidth: '100px' }}>Стоимость</th>
                <th style={{ minWidth: '120px' }}>Ссылка на акт</th>
              </tr>
            </thead>
            <tbody>
              {maintenanceLog.map((entry, index) => (
                <tr key={entry.id}>
                  <td>{index + 1}</td>
                  <td>{entry.repairDate ? new Date(entry.repairDate).toLocaleDateString('ru-RU') : '-'}</td>
                  <td>{entry.inventoryNumber}</td>
                  <td>{entry.equipmentType}</td>
                  <td>{entry.equipmentName}</td>
                  <td><span className={`status-badge ${entry.workType === 'ТО' ? 'status-active' : 'status-pending'}`}>{entry.workType}</span></td>
                  <td style={{ maxWidth: '200px', overflow: 'hidden', textOverflow: 'ellipsis' }}>{entry.performedWork || '-'}</td>
                  <td>{entry.manufacturer}</td>
                  <td>{entry.model}</td>
                  <td>{entry.installationLocation}</td>
                  <td>{entry.manufacturingDate ? new Date(entry.manufacturingDate).toLocaleDateString('ru-RU') : '-'}</td>
                  <td>{entry.commissioningDate ? new Date(entry.commissioningDate).toLocaleDateString('ru-RU') : '-'}</td>
                  <td>{entry.workWarranty || '-'}</td>
                  <td>{entry.performingOrganization}</td>
                  <td>{entry.cost ? entry.cost + ' ₽' : '-'}</td>
                  <td>
                    {entry.workActLink ? (
                      <button className="btn btn-secondary" style={{ padding: '0.25rem 0.5rem', fontSize: '0.8rem' }}>
                        {entry.workActLink}
                      </button>
                    ) : '-'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Add Maintenance Form Modal */}
        {showAddMaintenanceForm && (
          <div className="modal-overlay">
            <div className="modal-content" style={{
              maxWidth: '900px',
              width: '100%',
              maxHeight: '95vh',
              backgroundColor: 'white',
              borderRadius: '6px',
              border: '3px solid #2c3e50',
              padding: '1.5rem',
              display: 'flex',
              flexDirection: 'column',
              boxShadow: '0 5px 20px rgba(0, 0, 0, 0.3)'
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem', flexShrink: 0 }}>
                <h2 style={{
                  margin: 0,
                  fontSize: '1.1rem',
                  color: '#2c3e50',
                  fontWeight: '700',
                  textTransform: 'uppercase',
                  letterSpacing: '1px',
                  borderBottom: '3px solid #2c3e50',
                  paddingBottom: '0.8rem'
                }}>Добавить запись в журнал ТО и ремонтов складской техники</h2>
                <button 
                  onClick={() => setShowAddMaintenanceForm(false)}
                  style={{ background: 'none', border: 'none', fontSize: '1.5rem', cursor: 'pointer', color: '#666' }}
                >
                  ×
                </button>
              </div>
              
              <div style={{ overflowY: 'auto', flex: 1 }}>
                <form onSubmit={handleSubmitMaintenance}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                  <div className="form-group">
                    <label>Дата ремонта/ТО</label>
                    <input
                      type="date"
                      name="repairDate"
                      value={maintenanceFormData.repairDate}
                      onChange={handleMaintenanceFormChange}
                      required
                    />
                  </div>
                  
                  <div className="form-group">
                    <label>Инвентарный номер</label>
                    <input
                      type="text"
                      name="inventoryNumber"
                      value={maintenanceFormData.inventoryNumber}
                      onChange={handleMaintenanceFormChange}
                      required
                    />
                  </div>
                  
                  <div className="form-group">
                    <label>Тип оборудования</label>
                    <select
                      name="equipmentType"
                      value={maintenanceFormData.equipmentType}
                      onChange={handleMaintenanceFormChange}
                      required
                    >
                      <option value="">Выберите тип</option>
                      {equipmentTypes.map((type) => (
                        <option key={type} value={type}>{type}</option>
                      ))}
                    </select>
                  </div>
                  
                  {maintenanceFormData.equipmentType === 'Свой вариант' && (
                    <div className="form-group">
                      <label>Укажите тип оборудования</label>
                      <input
                        type="text"
                        name="customEquipmentType"
                        value={maintenanceFormData.customEquipmentType}
                        onChange={handleMaintenanceFormChange}
                        required
                      />
                    </div>
                  )}
                  
                  <div className="form-group">
                    <label>Название оборудования</label>
                    <input
                      type="text"
                      name="equipmentName"
                      value={maintenanceFormData.equipmentName}
                      onChange={handleMaintenanceFormChange}
                      required
                    />
                  </div>
                  
                  <div className="form-group">
                    <label>Вид работ</label>
                    <select
                      name="workType"
                      value={maintenanceFormData.workType}
                      onChange={handleMaintenanceFormChange}
                      required
                    >
                      <option value="">Выберите вид работ</option>
                      <option value="ТО">ТО</option>
                      <option value="Ремонт">Ремонт</option>
                    </select>
                  </div>
                  
                  <div className="form-group" style={{ gridColumn: '1 / -1' }}>
                    <label>Выполненные работы</label>
                    <textarea
                      name="performedWork"
                      value={maintenanceFormData.performedWork}
                      onChange={handleMaintenanceFormChange}
                      rows="3"
                    />
                  </div>
                  
                  <div className="form-group">
                    <label>Производитель</label>
                    <input
                      type="text"
                      name="manufacturer"
                      value={maintenanceFormData.manufacturer}
                      onChange={handleMaintenanceFormChange}
                    />
                  </div>
                  
                  <div className="form-group">
                    <label>Модель</label>
                    <input
                      type="text"
                      name="model"
                      value={maintenanceFormData.model}
                      onChange={handleMaintenanceFormChange}
                    />
                  </div>
                  
                  <div className="form-group">
                    <label>Место установки</label>
                    <input
                      type="text"
                      name="installationLocation"
                      value={maintenanceFormData.installationLocation}
                      onChange={handleMaintenanceFormChange}
                    />
                  </div>
                  
                  <div className="form-group">
                    <label>Дата производства</label>
                    <input
                      type="date"
                      name="manufacturingDate"
                      value={maintenanceFormData.manufacturingDate}
                      onChange={handleMaintenanceFormChange}
                    />
                  </div>
                  
                  <div className="form-group">
                    <label>Дата ввода в эксплуатацию</label>
                    <input
                      type="date"
                      name="commissioningDate"
                      value={maintenanceFormData.commissioningDate}
                      onChange={handleMaintenanceFormChange}
                    />
                  </div>
                  
                  <div className="form-group">
                    <label>Гарантия на выполненные работы</label>
                    <input
                      type="text"
                      name="workWarranty"
                      value={maintenanceFormData.workWarranty}
                      onChange={handleMaintenanceFormChange}
                    />
                  </div>
                  
                  <div className="form-group">
                    <label>Организация-исполнитель</label>
                    <input
                      type="text"
                      name="performingOrganization"
                      value={maintenanceFormData.performingOrganization}
                      onChange={handleMaintenanceFormChange}
                    />
                  </div>
                  
                  <div className="form-group">
                    <label>Стоимость (₽)</label>
                    <input
                      type="number"
                      name="cost"
                      value={maintenanceFormData.cost}
                      onChange={handleMaintenanceFormChange}
                    />
                  </div>
                  
                  <div className="form-group">
                    <label>Ссылка на акт выполненных работ</label>
                    <input
                      type="text"
                      name="workActLink"
                      value={maintenanceFormData.workActLink}
                      onChange={handleMaintenanceFormChange}
                    />
                  </div>
                </div>
                
                <div className="form-actions" style={{
                  marginTop: '1.5rem',
                  display: 'flex',
                  justifyContent: 'flex-end',
                  gap: '1rem',
                  paddingTop: '1rem',
                  borderTop: '3px solid #2c3e50',
                  position: 'sticky',
                  bottom: 0,
                  backgroundColor: 'white'
                }}>
                  <button 
                    type="button" 
                    className="btn btn-secondary"
                    onClick={() => setShowAddMaintenanceForm(false)}
                    style={{ padding: '0.6rem 1.2rem', fontSize: '0.9rem' }}
                  >
                    Отмена
                  </button>
                  <button 
                    type="submit" 
                    className="btn btn-primary"
                    style={{ padding: '0.6rem 1.2rem', fontSize: '0.9rem' }}
                  >
                    Добавить запись
                  </button>
                </div>
              </form>
              </div>
            </div>
          </div>
        )}
      </div>
    )
  }

  if (loading) return <div className="loading">Загрузка данных...</div>

  return (
    <div className="module-page">
      <div className="module-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <button 
            className="btn btn-secondary"
            onClick={() => navigate('/')}
            style={{ padding: '0.5rem 1rem' }}
          >
            ← Назад к панели
          </button>
          <h1 className="module-title" style={{ color: 'white' }}>Складская Техника</h1>
        </div>
        <div>
          <button className="btn btn-primary">+ Добавить технику</button>
        </div>
      </div>

      {/* Subsections Navigation */}
      <div style={{ marginBottom: '2rem' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1rem' }}>
          {subSections.map((subSection) => (
            <div
              key={subSection.id}
              onClick={() => setActiveSubSection(subSection.id)}
              className={`subsection-card ${
                activeSubSection === subSection.id ? 'active' : ''
              }`}
              style={{
                cursor: 'pointer',
                minHeight: '120px',
                border: activeSubSection === subSection.id ? '2px solid #667eea' : '2px solid transparent'
              }}
            >
              <div className="icon">{subSection.icon}</div>
              <h3 style={{ fontSize: '1.1rem' }}>{subSection.name}</h3>
              <p style={{ fontSize: '0.85rem' }}>{subSection.description}</p>
            </div>
          ))}
        </div>
      </div>

      {error && (
        <div className="error" style={{ 
          marginBottom: '2rem', 
          padding: '1rem', 
          backgroundColor: '#ffe6e6', 
          border: '1px solid #ff9999', 
          borderRadius: '4px', 
          color: '#cc0000' 
        }}>
          ⚠️ {error}
        </div>
      )}

      {/* Dynamic Content based on active subsection */}
      {renderSubSectionContent()}
    </div>
  )
}

export default Machinery