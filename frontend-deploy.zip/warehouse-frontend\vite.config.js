import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  build: {
    // Enable minification
    minify: 'terser',
    // Enable CSS code splitting
    cssCodeSplit: true,
    // Optimize chunks
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom'],
          router: ['react-router-dom'],
          api: ['axios']
        }
      }
    },
    // Enable source maps for production debugging
    sourcemap: false,
    // Set chunk size warning limit
    chunkSizeWarningLimit: 1000
  },
  // Optimize dev server
  server: {
    port: 5176,
    host: true,
    // Enable hot reload optimization
    hmr: {
      overlay: true
    }
  },
  // Enable CSS preprocessing optimizations
  css: {
    // Enable CSS modules
    modules: false,
    // PostCSS optimizations
    postcss: {}
  },
  // Define aliases for better tree-shaking
  resolve: {
    alias: {
      '@': '/src',
      '@components': '/src/components',
      '@services': '/src/services'
    }
  },
  // Optimize dependencies
  optimizeDeps: {
    include: ['react', 'react-dom', 'react-router-dom', 'axios'],
    exclude: []
  }
})
