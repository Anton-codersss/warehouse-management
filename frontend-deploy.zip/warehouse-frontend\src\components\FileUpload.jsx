import { useState, useRef } from 'react'

function FileUpload({ onFileSelect, multiple = false, acceptedTypes = "*", maxSize = 10, label = "Прикрепить файл" }) {
  const [dragActive, setDragActive] = useState(false)
  const [uploadedFiles, setUploadedFiles] = useState([])
  const fileInputRef = useRef(null)

  const handleDrag = (e) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }

  const handleDrop = (e) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFiles(e.dataTransfer.files)
    }
  }

  const handleChange = (e) => {
    e.preventDefault()
    if (e.target.files && e.target.files[0]) {
      handleFiles(e.target.files)
    }
  }

  const handleFiles = (files) => {
    const fileArray = Array.from(files)
    const validFiles = fileArray.filter(file => {
      // Check file size (convert MB to bytes)
      const maxSizeBytes = maxSize * 1024 * 1024
      if (file.size > maxSizeBytes) {
        alert(`Файл "${file.name}" слишком большой. Максимальный размер: ${maxSize}MB`)
        return false
      }
      return true
    })

    if (multiple) {
      setUploadedFiles(prev => [...prev, ...validFiles])
      onFileSelect([...uploadedFiles, ...validFiles])
    } else {
      setUploadedFiles(validFiles.slice(0, 1))
      onFileSelect(validFiles[0])
    }
  }

  const removeFile = (index) => {
    const newFiles = uploadedFiles.filter((_, i) => i !== index)
    setUploadedFiles(newFiles)
    onFileSelect(multiple ? newFiles : null)
  }

  const openFileDialog = () => {
    fileInputRef.current?.click()
  }

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  return (
    <div className="file-upload-container">
      <div
        className={`file-upload-zone ${dragActive ? 'drag-active' : ''}`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        onClick={openFileDialog}
        style={{
          border: '2px dashed #ccc',
          borderRadius: '8px',
          padding: '2rem',
          textAlign: 'center',
          cursor: 'pointer',
          backgroundColor: dragActive ? '#f0f8ff' : '#fafafa',
          borderColor: dragActive ? '#667eea' : '#ccc',
          transition: 'all 0.3s ease'
        }}
      >
        <input
          ref={fileInputRef}
          type="file"
          multiple={multiple}
          accept={acceptedTypes}
          onChange={handleChange}
          style={{ display: 'none' }}
        />
        <div style={{ marginBottom: '1rem' }}>
          <span style={{ fontSize: '2rem', color: '#667eea' }}>📎</span>
        </div>
        <p style={{ margin: '0.5rem 0', fontWeight: '500' }}>{label}</p>
        <p style={{ fontSize: '0.9rem', color: '#666' }}>
          Перетащите файлы сюда или кликните для выбора
        </p>
        <p style={{ fontSize: '0.8rem', color: '#999', marginTop: '0.5rem' }}>
          Максимальный размер: {maxSize}MB {multiple ? '(можно выбрать несколько)' : ''}
        </p>
      </div>

      {uploadedFiles.length > 0 && (
        <div style={{ marginTop: '1rem' }}>
          <h4 style={{ marginBottom: '0.5rem', color: '#333' }}>Прикрепленные файлы:</h4>
          <div className="uploaded-files-list">
            {uploadedFiles.map((file, index) => (
              <div
                key={index}
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  padding: '0.75rem',
                  border: '1px solid #e0e0e0',
                  borderRadius: '6px',
                  marginBottom: '0.5rem',
                  backgroundColor: '#fff'
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', flex: 1 }}>
                  <span style={{ marginRight: '0.5rem' }}>
                    {file.type.includes('image') ? '🖼️' : 
                     file.type.includes('pdf') ? '📄' : 
                     file.type.includes('doc') ? '📝' : 
                     file.type.includes('excel') || file.type.includes('spreadsheet') ? '📊' : '📋'}
                  </span>
                  <div>
                    <div style={{ fontWeight: '500', fontSize: '0.9rem' }}>{file.name}</div>
                    <div style={{ fontSize: '0.8rem', color: '#666' }}>
                      {formatFileSize(file.size)} • {file.type || 'Неизвестный тип'}
                    </div>
                  </div>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation()
                    removeFile(index)
                  }}
                  style={{
                    background: '#dc3545',
                    color: 'white',
                    border: 'none',
                    borderRadius: '4px',
                    padding: '0.25rem 0.5rem',
                    cursor: 'pointer',
                    fontSize: '0.8rem'
                  }}
                >
                  Удалить
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

export default FileUpload