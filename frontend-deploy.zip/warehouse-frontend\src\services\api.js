import axios from 'axios'

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api'

// Simple in-memory cache
const cache = new Map()
const CACHE_DURATION = 5 * 60 * 1000 // 5 minutes

// Request deduplication map
const pendingRequests = new Map()

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000,
})

// Request interceptor for caching GET requests and authentication
api.interceptors.request.use(
  (config) => {
    // Add authentication token
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    
    // Only cache GET requests
    if (config.method === 'get') {
      const cacheKey = `${config.method}:${config.url}`
      
      // Check if request is already pending
      if (pendingRequests.has(cacheKey)) {
        return pendingRequests.get(cacheKey)
      }
      
      // Check cache
      const cached = cache.get(cacheKey)
      if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
        return Promise.resolve(cached.data)
      }
      
      // Store pending request
      pendingRequests.set(cacheKey, config)
    }
    
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// Response interceptor for error handling and caching
api.interceptors.response.use(
  (response) => {
    // Cache GET responses
    if (response.config && response.config.method === 'get') {
      const cacheKey = `${response.config.method}:${response.config.url}`
      cache.set(cacheKey, {
        data: response,
        timestamp: Date.now()
      })
      // Remove from pending requests
      pendingRequests.delete(cacheKey)
    }
    return response
  },
  (error) => {
    // Remove from pending requests on error
    if (error.config) {
      const cacheKey = `${error.config.method}:${error.config.url}`
      pendingRequests.delete(cacheKey)
    }
    
    // Handle authentication errors
    if (error.response?.status === 401) {
      localStorage.removeItem('token')
      localStorage.removeItem('user')
      window.location.href = '/'
    }
    
    console.error('API Error:', error)
    if (error.code === 'ECONNREFUSED') {
      console.error('Backend server is not running')
    }
    return Promise.reject(error)
  }
)

// Clear cache function
export const clearCache = () => {
  cache.clear()
  pendingRequests.clear()
}

// API functions for authentication
export const authAPI = {
  login: (username, password) => api.post('/auth/login', { username, password }),
  verify: () => api.get('/auth/verify'),
  logout: () => api.post('/auth/logout')
}

// API functions for each module
export const equipmentAPI = {
  getAll: () => api.get('/equipment'),
  getById: (id) => api.get(`/equipment/${id}`),
  create: (data) => api.post('/equipment', data),
  update: (id, data) => api.put(`/equipment/${id}`, data),
  delete: (id) => api.delete(`/equipment/${id}`),
  
  // Maintenance log methods
  getMaintenanceLog: () => api.get('/equipment/maintenance-log'),
  createMaintenanceEntry: (data) => api.post('/equipment/maintenance-log', data),
  updateMaintenanceEntry: (id, data) => api.put(`/equipment/maintenance-log/${id}`, data),
  deleteMaintenanceEntry: (id) => api.delete(`/equipment/maintenance-log/${id}`),
}

export const machineryAPI = {
  getAll: () => api.get('/machinery'),
  getById: (id) => api.get(`/machinery/${id}`),
  create: (data) => api.post('/machinery', data),
  update: (id, data) => api.put(`/machinery/${id}`, data),
  delete: (id) => api.delete(`/machinery/${id}`),
}

export const pestControlAPI = {
  getAll: () => api.get('/pest-control'),
  getById: (id) => api.get(`/pest-control/${id}`),
  create: (data) => api.post('/pest-control', data),
  update: (id, data) => api.put(`/pest-control/${id}`, data),
  delete: (id) => api.delete(`/pest-control/${id}`),
}

export const energyResourcesAPI = {
  getAll: () => api.get('/energy-resources'),
  getById: (id) => api.get(`/energy-resources/${id}`),
  create: (data) => api.post('/energy-resources', data),
  update: (id, data) => api.put(`/energy-resources/${id}`, data),
  delete: (id) => api.delete(`/energy-resources/${id}`),
}

export const emergencyAPI = {
  getAll: () => api.get('/emergency'),
  getById: (id) => api.get(`/emergency/${id}`),
  create: (data) => api.post('/emergency', data),
  update: (id, data) => api.put(`/emergency/${id}`, data),
  delete: (id) => api.delete(`/emergency/${id}`),
}

export const worksAPI = {
  getAll: () => api.get('/works'),
  getById: (id) => api.get(`/works/${id}`),
  create: (data) => api.post('/works', data),
  update: (id, data) => api.put(`/works/${id}`, data),
  delete: (id) => api.delete(`/works/${id}`),
}

export const schemesAPI = {
  getAll: () => api.get('/schemes'),
  getById: (id) => api.get(`/schemes/${id}`),
  create: (data) => api.post('/schemes', data),
  update: (id, data) => api.put(`/schemes/${id}`, data),
  delete: (id) => api.delete(`/schemes/${id}`),
}

export const consumablesAPI = {
  getAll: () => api.get('/consumables'),
  getById: (id) => api.get(`/consumables/${id}`),
  getLowStock: () => api.get('/consumables/low-stock'),
  create: (data) => api.post('/consumables', data),
  update: (id, data) => api.put(`/consumables/${id}`, data),
  delete: (id) => api.delete(`/consumables/${id}`),
}

export const secondaryMaterialsAPI = {
  getAll: () => api.get('/secondary-materials'),
  getById: (id) => api.get(`/secondary-materials/${id}`),
  create: (data) => api.post('/secondary-materials', data),
  update: (id, data) => api.put(`/secondary-materials/${id}`, data),
  delete: (id) => api.delete(`/secondary-materials/${id}`),
}

// File upload API
export const filesAPI = {
  upload: (files, category, equipmentId, description = '') => {
    const formData = new FormData()
    
    // Add files to FormData
    files.forEach(file => {
      formData.append('files', file)
    })
    
    // Add metadata
    formData.append('category', category)
    formData.append('equipmentId', equipmentId)
    formData.append('description', description)
    
    return api.post('/files/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    })
  },
  
  list: (equipmentId) => api.get(`/files/list/${equipmentId}`),
  
  download: (category, equipmentId, filename) => {
    return api.get(`/files/download/${category}/${equipmentId}/${filename}`, {
      responseType: 'blob',
    })
  },
  
  delete: (category, equipmentId, filename) => {
    return api.delete(`/files/delete/${category}/${equipmentId}/${filename}`)
  },
}

export default api