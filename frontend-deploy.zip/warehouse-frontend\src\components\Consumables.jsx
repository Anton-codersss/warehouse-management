import { useState, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { consumablesAPI } from '../services/api'

function Consumables() {
  const navigate = useNavigate()
  const [consumables, setConsumables] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchConsumables()
  }, [])

  const fetchConsumables = async () => {
    try {
      const response = await consumablesAPI.getAll()
      setConsumables(response.data)
    } catch (err) {
      console.error('Error:', err)
    } finally {
      setLoading(false)
    }
  }

  if (loading) return <div className="loading">Загрузка данных...</div>

  return (
    <div className="module-page">
      <div className="module-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <button 
            className="btn btn-secondary"
            onClick={() => navigate('/')}
            style={{ padding: '0.5rem 1rem' }}
          >
            ← Назад к панели
          </button>
          <h1 className="module-title" style={{ color: 'white' }}>Расходные материалы</h1>
        </div>
        <button className="btn btn-primary">+ Добавить материал</button>
      </div>
      <div className="data-grid">
        {consumables.length === 0 ? (
          <div className="no-data"><p>Нет данных о расходных материалах</p></div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Название</th>
                <th>Категория</th>
                <th>Текущий остаток</th>
                <th>Единица</th>
                <th>Поставщик</th>
              </tr>
            </thead>
            <tbody>
              {consumables.map((item) => (
                <tr key={item.id}>
                  <td>{item.name}</td>
                  <td>{item.category || '-'}</td>
                  <td>{item.current_stock}</td>
                  <td>{item.unit}</td>
                  <td>{item.supplier || '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}

export default Consumables