import { Link } from 'react-router-dom'

function Header({ user, onLogout }) {
  return (
    <header className="header">
      <h1>
        <Link to="/" style={{ color: 'white', textDecoration: 'none' }}>
          Система управления складским комплексом
        </Link>
      </h1>
      
      {user && (
        <div className="user-info">
          <span className="user-name">{user.name}</span>
          <span className="user-role">{user.role === 'admin' ? 'Администратор' : 'Оператор'}</span>
          <button className="logout-button" onClick={onLogout}>
            Выход
          </button>
        </div>
      )}
    </header>
  )
}

export default Header