import React, { useState, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import FileUpload from './FileUpload'

function EnergyResources() {
  const navigate = useNavigate()
  const [activeSubSection, setActiveSubSection] = useState('overview')
  const [meterRegistry, setMeterRegistry] = useState([])
  const [electricityReadings, setElectricityReadings] = useState([])
  const [waterReadings, setWaterReadings] = useState([])
  const [thermalReadings, setThermalReadings] = useState([])
  const [tkoLog, setTkoLog] = useState([])
  const [tboLog, setTboLog] = useState([])
  const [temperatureLog, setTemperatureLog] = useState([])
  const [humidityLog, setHumidityLog] = useState([])
  const [showAddForm, setShowAddForm] = useState(false)
  const [currentFormType, setCurrentFormType] = useState('')
  const [formData, setFormData] = useState({})

  useEffect(() => {
    // Initialize sample data
    initializeSampleData()
  }, [])

  const initializeSampleData = () => {
    // Meter Registry Sample Data
    setMeterRegistry([
      {
        id: 1,
        serialNumber: 1,
        energyType: 'Электроэнергия',
        manufacturer: 'Энергомер',
        deviceSerial: 'EM-2024-001',
        manufacturingDate: '2024-01-15',
        nextVerificationDate: '2025-01-15',
        location: 'Главный щит',
        transformationRatio: '100/5'
      },
      {
        id: 2,
        serialNumber: 2,
        energyType: 'Водоснабжение',
        manufacturer: 'Водомер',
        deviceSerial: 'WM-2024-002',
        manufacturingDate: '2024-02-10',
        nextVerificationDate: '2025-02-10',
        location: 'Техническое помещение',
        transformationRatio: '-'
      }
    ])

    // Electricity Readings Sample Data
    setElectricityReadings([
      {
        id: 1,
        readingDate: '2024-12-01',
        location: 'Главный щит',
        meterNumber: 'EM-2024-001',
        transformationRatio: '100/5',
        currentReading: '15240',
        periodConsumption: '1250',
        tariff: '4.50',
        amount: '5625.00'
      }
    ])

    // Water Readings Sample Data
    setWaterReadings([
      {
        id: 1,
        readingDate: '2024-12-01',
        location: 'Техническое помещение',
        meterNumber: 'WM-2024-002',
        currentReading: '8540',
        periodConsumption: '150',
        tariff: '25.30',
        amount: '3795.00'
      }
    ])

    // Thermal Energy Sample Data
    setThermalReadings([
      {
        id: 1,
        readingDate: '2024-12-01',
        location: 'Зона отопления',
        meterNumber: 'TM-2024-003',
        currentReading: '2840',
        periodConsumption: '85',
        tariff: '1850.00',
        amount: '157250.00'
      }
    ])

    // Temperature Log Sample Data
    setTemperatureLog([
      {
        id: 1,
        date: '2024-12-15',
        time: '09:00',
        zone: 'Зона А1',
        temperature: '18.5',
        humidity: '55',
        responsible: 'Смирнов А.А.',
        notes: 'Норма'
      },
      {
        id: 2,
        date: '2024-12-15',
        time: '15:00',
        zone: 'Зона А2',
        temperature: '19.2',
        humidity: '52',
        responsible: 'Петров Б.Б.',
        notes: 'Норма'
      }
    ])

    // TKO Log Sample Data
    setTkoLog([
      {
        id: 1,
        date: '2024-12-10',
        wasteType: 'Мишанные отходы',
        volume: '15.5',
        unit: 'м³',
        transportCompany: 'ООО "ЭкоТранс"',
        cost: '8500.00',
        documentNumber: 'Накладная №123'
      }
    ])
  }

  const subSections = [
    { id: 'overview', name: 'Обзор энергоресурсов', icon: '🔌', description: 'Общая информация о потреблении энергоресурсов' },
    
    // 4.1 Энергопотребление
    { id: 'meter-registry', name: 'Реестр приборов учета', icon: '📊', description: 'Список всех приборов учета энергоресурсов' },
    { id: 'electricity-readings', name: 'Показания - Электроэнергия', icon: '⚡', description: 'Журнал показаний приборов электроэнергии' },
    { id: 'water-readings', name: 'Показания - Вода', icon: '💧', description: 'Журнал показаний приборов водоснабжения' },
    { id: 'thermal-readings', name: 'Показания - Тепло', icon: '🔥', description: 'Журнал показаний тепловой энергии' },
    { id: 'tko-log', name: 'Журнал вывоза ТКО', icon: '🗑️', description: 'Учет вывоза твердых коммунальных отходов' },
    { id: 'tbo-log', name: 'Журнал вывоза ТБО', icon: '♾️', description: 'Учет вывоза твердых бытовых отходов' },
    
    // 4.2 Температурный контроль
    { id: 'temperature-control', name: 'Температурный контроль', icon: '🌡️', description: 'Журнал учета температуры на складе' },
    
    // 4.3 Влажность
    { id: 'humidity-control', name: 'Контроль влажности', icon: '💨', description: 'Журнал учета влажности на складе' },
    
    // 4.4 Рекомендации
    { id: 'optimization', name: 'Рекомендации по оптимизации', icon: '💡', description: 'Анализ и рекомендации по оптимизации потребления' }
  ]

  const handleFormChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmitForm = (e) => {
    e.preventDefault()
    const newEntry = {
      id: Date.now(),
      ...formData
    }

    switch (currentFormType) {
      case 'meter':
        setMeterRegistry(prev => [...prev, newEntry])
        break
      case 'electricity':
        setElectricityReadings(prev => [...prev, newEntry])
        break
      case 'water':
        setWaterReadings(prev => [...prev, newEntry])
        break
      case 'thermal':
        setThermalReadings(prev => [...prev, newEntry])
        break
      case 'temperature':
        setTemperatureLog(prev => [...prev, newEntry])
        break
      case 'tko':
        setTkoLog(prev => [...prev, newEntry])
        break
      default:
        break
    }

    setFormData({})
    setShowAddForm(false)
    setCurrentFormType('')
  }

  const openAddForm = (formType) => {
    setCurrentFormType(formType)
    setFormData({})
    setShowAddForm(true)
  }

  const renderSubSectionContent = () => {
    switch (activeSubSection) {
      case 'overview':
        return renderOverview()
      case 'meter-registry':
        return renderMeterRegistry()
      case 'electricity-readings':
        return renderElectricityReadings()
      case 'water-readings':
        return renderWaterReadings()
      case 'thermal-readings':
        return renderThermalReadings()
      case 'tko-log':
        return renderTKOLog()
      case 'tbo-log':
        return renderTBOLog()
      case 'temperature-control':
        return renderTemperatureControl()
      case 'humidity-control':
        return renderHumidityControl()
      case 'optimization':
        return renderOptimization()
      default:
        return renderOverview()
    }
  }

  const renderOverview = () => {
    return (
      <div>
        <h3>Обзор энергоресурсов</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '1rem', marginTop: '2rem' }}>
          <div className="dashboard-card" style={{ textAlign: 'center', padding: '2rem' }}>
            <h4>Электроэнергия</h4>
            <p style={{ fontSize: '1.5rem', color: '#667eea', fontWeight: 'bold' }}>5,625 руб</p>
            <p style={{ fontSize: '0.9rem', color: '#666' }}>Текущий месяц</p>
          </div>
          <div className="dashboard-card" style={{ textAlign: 'center', padding: '2rem' }}>
            <h4>Водоснабжение</h4>
            <p style={{ fontSize: '1.5rem', color: '#667eea', fontWeight: 'bold' }}>3,795 руб</p>
            <p style={{ fontSize: '0.9rem', color: '#666' }}>Текущий месяц</p>
          </div>
          <div className="dashboard-card" style={{ textAlign: 'center', padding: '2rem' }}>
            <h4>Тепловая энергия</h4>
            <p style={{ fontSize: '1.5rem', color: '#667eea', fontWeight: 'bold' }}>157,250 руб</p>
            <p style={{ fontSize: '0.9rem', color: '#666' }}>Текущий месяц</p>
          </div>
          <div className="dashboard-card" style={{ textAlign: 'center', padding: '2rem' }}>
            <h4>Температура</h4>
            <p style={{ fontSize: '1.5rem', color: '#27ae60', fontWeight: 'bold' }}>18.9°C</p>
            <p style={{ fontSize: '0.9rem', color: '#666' }}>Средняя по складу</p>
          </div>
        </div>
      </div>
    )
  }

  // Additional render functions (simplified)
  const renderMeterRegistry = () => <div><h3>Реестр приборов учета</h3><div className="data-grid"><table><thead><tr><th>№</th><th>Тип энергии</th><th>Производитель</th><th>Серийный номер</th><th>Месторасположение</th></tr></thead><tbody>{meterRegistry.map((meter) => <tr key={meter.id}><td>{meter.serialNumber}</td><td>{meter.energyType}</td><td>{meter.manufacturer}</td><td>{meter.deviceSerial}</td><td>{meter.location}</td></tr>)}</tbody></table></div></div>
  const renderElectricityReadings = () => <div><h3>Электроэнергия</h3><div className="data-grid"><table><thead><tr><th>Дата</th><th>Место</th><th>Показания</th><th>Сумма</th></tr></thead><tbody>{electricityReadings.map((r) => <tr key={r.id}><td>{new Date(r.readingDate).toLocaleDateString('ru-RU')}</td><td>{r.location}</td><td>{r.currentReading}</td><td>{r.amount}</td></tr>)}</tbody></table></div></div>
  const renderWaterReadings = () => <div><h3>Вода</h3><div className="data-grid"><table><thead><tr><th>Дата</th><th>Место</th><th>Показания</th><th>Сумма</th></tr></thead><tbody>{waterReadings.map((r) => <tr key={r.id}><td>{new Date(r.readingDate).toLocaleDateString('ru-RU')}</td><td>{r.location}</td><td>{r.currentReading}</td><td>{r.amount}</td></tr>)}</tbody></table></div></div>
  const renderThermalReadings = () => <div><h3>Тепловая энергия</h3><div className="data-grid"><table><thead><tr><th>Дата</th><th>Место</th><th>Показания</th><th>Сумма</th></tr></thead><tbody>{thermalReadings.map((r) => <tr key={r.id}><td>{new Date(r.readingDate).toLocaleDateString('ru-RU')}</td><td>{r.location}</td><td>{r.currentReading}</td><td>{r.amount}</td></tr>)}</tbody></table></div></div>
  const renderTKOLog = () => <div><h3>ТКО</h3><div className="data-grid"><table><thead><tr><th>Дата</th><th>Тип</th><th>Объем</th><th>Стоимость</th></tr></thead><tbody>{tkoLog.map((entry) => <tr key={entry.id}><td>{new Date(entry.date).toLocaleDateString('ru-RU')}</td><td>{entry.wasteType}</td><td>{entry.volume}</td><td>{entry.cost}</td></tr>)}</tbody></table></div></div>
  const renderTBOLog = () => <div><h3>ТБО</h3><div className="no-data"><p>В разработке</p></div></div>
  const renderTemperatureControl = () => <div><h3>Температура</h3><div className="data-grid"><table><thead><tr><th>Дата</th><th>Зона</th><th>Температура</th><th>Влажность</th></tr></thead><tbody>{temperatureLog.map((entry) => <tr key={entry.id}><td>{new Date(entry.date).toLocaleDateString('ru-RU')}</td><td>{entry.zone}</td><td>{entry.temperature}°C</td><td>{entry.humidity}%</td></tr>)}</tbody></table></div></div>
  const renderHumidityControl = () => <div><h3>Влажность</h3><div className="no-data"><p>Данные ведутся совместно с температурой</p></div></div>
  const renderOptimization = () => <div><h3>Оптимизация</h3><div className="no-data"><p>Анализ и рекомендации</p></div></div>

  return (
    <div className="module-page">
      <div className="module-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <button 
            className="btn btn-secondary"
            onClick={() => navigate('/')}
            style={{ padding: '0.5rem 1rem' }}
          >
            ← Назад к панели
          </button>
          <h1 className="module-title" style={{ color: 'white' }}>Энергоресурсы</h1>
        </div>
        <button className="btn btn-primary">+ Добавить запись</button>
      </div>

      {/* Subsections Navigation */}
      <div style={{ marginBottom: '2rem' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1rem' }}>
          {subSections.map((subSection) => (
            <div
              key={subSection.id}
              onClick={() => setActiveSubSection(subSection.id)}
              className={`subsection-card ${
                activeSubSection === subSection.id ? 'active' : ''
              }`}
              style={{
                cursor: 'pointer',
                minHeight: '120px',
                border: activeSubSection === subSection.id ? '2px solid #667eea' : '2px solid transparent'
              }}
            >
              <div className="icon">{subSection.icon}</div>
              <h3 style={{ fontSize: '1rem' }}>{subSection.name}</h3>
              <p style={{ fontSize: '0.85rem' }}>{subSection.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Dynamic Content */}
      {renderSubSectionContent()}
    </div>
  )
}

export default EnergyResources