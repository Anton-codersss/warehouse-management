import { useEffect } from 'react'

const PerformanceMonitor = () => {
  useEffect(() => {
    // Performance monitoring in development
    if (process.env.NODE_ENV === 'development') {
      // Monitor Core Web Vitals
      const observer = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          console.log('Performance:', entry.name, entry.value)
        }
      })
      
      // Observe paint timing
      observer.observe({ entryTypes: ['paint'] })
      
      // Monitor memory usage if available
      if ('memory' in performance) {
        const logMemory = () => {
          const memory = performance.memory
          console.log('Memory Usage:', {
            used: Math.round(memory.usedJSHeapSize / 1048576) + ' MB',
            total: Math.round(memory.totalJSHeapSize / 1048576) + ' MB',
            limit: Math.round(memory.jsHeapSizeLimit / 1048576) + ' MB'
          })
        }
        
        // Log memory usage every 30 seconds
        const interval = setInterval(logMemory, 30000)
        
        return () => {
          observer.disconnect()
          clearInterval(interval)
        }
      }
      
      return () => observer.disconnect()
    }
  }, [])
  
  return null
}

export default PerformanceMonitor