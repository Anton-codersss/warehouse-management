import { Link, useNavigate } from 'react-router-dom'

function Emergency() {
  const navigate = useNavigate()
  
  return (
    <div className="module-page">
      <div className="module-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <button 
            className="btn btn-secondary"
            onClick={() => navigate('/')}
            style={{ padding: '0.5rem 1rem' }}
          >
            ← Назад к панели
          </button>
          <h1 className="module-title" style={{ color: 'white' }}>Аварийные ситуации</h1>
        </div>
        <button className="btn btn-primary">+ Добавить запись</button>
      </div>
      <div className="no-data"><p>Модуль аварийных ситуаций в разработке</p></div>
    </div>
  )
}

export default Emergency