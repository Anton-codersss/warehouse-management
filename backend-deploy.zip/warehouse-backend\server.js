const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
require('dotenv').config();

const { authenticateToken } = require('./routes/auth');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(helmet());
app.use(cors({
    origin: process.env.FRONTEND_URL || 'http://localhost:5176',
    credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Logging middleware
app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
    console.log('Headers:', req.headers);
    if (req.body && Object.keys(req.body).length > 0) {
        console.log('Body:', req.body);
    }
    next();
});

// Import routes
const authRoutes = require('./routes/auth');
const equipmentRoutes = require('./routes/equipment');
const machineryRoutes = require('./routes/machinery');
const pestControlRoutes = require('./routes/pestControl');
const energyResourcesRoutes = require('./routes/energyResources');
const emergencyRoutes = require('./routes/emergency');
const worksRoutes = require('./routes/works');
const schemesRoutes = require('./routes/schemes');
const consumablesRoutes = require('./routes/consumables');
const secondaryMaterialsRoutes = require('./routes/secondaryMaterials');
const filesRoutes = require('./routes/files');

// Public routes (no authentication required)
app.use('/api/auth', authRoutes.router);

// Protected routes (authentication required)
app.use('/api/equipment', authenticateToken, equipmentRoutes);
app.use('/api/machinery', authenticateToken, machineryRoutes);
app.use('/api/pest-control', authenticateToken, pestControlRoutes);
app.use('/api/energy-resources', authenticateToken, energyResourcesRoutes);
app.use('/api/emergency', authenticateToken, emergencyRoutes);
app.use('/api/works', authenticateToken, worksRoutes);
app.use('/api/schemes', authenticateToken, schemesRoutes);
app.use('/api/consumables', authenticateToken, consumablesRoutes);
app.use('/api/secondary-materials', authenticateToken, secondaryMaterialsRoutes);
app.use('/api/files', authenticateToken, filesRoutes);

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({ status: 'OK', message: 'Warehouse Management Server is running' });
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ message: 'Something went wrong!' });
});

// 404 handler
app.use((req, res) => {
    res.status(404).json({ message: 'Route not found' });
});

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});