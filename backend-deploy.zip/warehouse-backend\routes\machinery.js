const express = require('express');
const router = express.Router();
const pool = require('../config/database');
const { mockMachinery } = require('../data/mockData');

// Get all machinery
router.get('/', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM machinery ORDER BY created_at DESC');
        res.json(result.rows);
    } catch (error) {
        console.error('Database error, using mock data:', error.message);
        // Use mock data when database is not available
        res.json(mockMachinery);
    }
});

// Get machinery by ID
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await pool.query('SELECT * FROM machinery WHERE id = $1', [id]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Machinery not found' });
        }
        
        res.json(result.rows[0]);
    } catch (error) {
        console.error('Error fetching machinery:', error);
        res.status(500).json({ message: 'Error fetching machinery' });
    }
});

// Create new machinery
router.post('/', async (req, res) => {
    try {
        const {
            name, type, brand, model, license_plate, status, fuel_type,
            last_service, next_service, location, description
        } = req.body;

        const result = await pool.query(
            `INSERT INTO machinery (name, type, brand, model, license_plate, status, 
             fuel_type, last_service, next_service, location, description) 
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11) RETURNING *`,
            [name, type, brand, model, license_plate, status, fuel_type,
             last_service, next_service, location, description]
        );

        res.status(201).json(result.rows[0]);
    } catch (error) {
        console.error('Error creating machinery:', error);
        res.status(500).json({ message: 'Error creating machinery' });
    }
});

// Update machinery
router.put('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const {
            name, type, brand, model, license_plate, status, fuel_type,
            last_service, next_service, location, description
        } = req.body;

        const result = await pool.query(
            `UPDATE machinery SET name = $1, type = $2, brand = $3, model = $4,
             license_plate = $5, status = $6, fuel_type = $7, last_service = $8,
             next_service = $9, location = $10, description = $11, 
             updated_at = CURRENT_TIMESTAMP WHERE id = $12 RETURNING *`,
            [name, type, brand, model, license_plate, status, fuel_type,
             last_service, next_service, location, description, id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Machinery not found' });
        }

        res.json(result.rows[0]);
    } catch (error) {
        console.error('Error updating machinery:', error);
        res.status(500).json({ message: 'Error updating machinery' });
    }
});

// Delete machinery
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await pool.query('DELETE FROM machinery WHERE id = $1 RETURNING *', [id]);

        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Machinery not found' });
        }

        res.json({ message: 'Machinery deleted successfully' });
    } catch (error) {
        console.error('Error deleting machinery:', error);
        res.status(500).json({ message: 'Error deleting machinery' });
    }
});

module.exports = router;