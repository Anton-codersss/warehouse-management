const express = require('express');
const router = express.Router();
const pool = require('../config/database');

// Get all emergency situations
router.get('/', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM emergency_situations ORDER BY incident_date DESC');
        res.json(result.rows);
    } catch (error) {
        console.error('Error fetching emergency situations:', error);
        res.status(500).json({ message: 'Error fetching emergency situations' });
    }
});

// Get emergency situation by ID
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await pool.query('SELECT * FROM emergency_situations WHERE id = $1', [id]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Emergency situation not found' });
        }
        
        res.json(result.rows[0]);
    } catch (error) {
        console.error('Error fetching emergency situation:', error);
        res.status(500).json({ message: 'Error fetching emergency situation' });
    }
});

// Create new emergency situation
router.post('/', async (req, res) => {
    try {
        const {
            incident_type, severity_level, location, incident_date, reported_by,
            description, status, assigned_to, resolution_date, resolution_description
        } = req.body;

        const result = await pool.query(
            `INSERT INTO emergency_situations (incident_type, severity_level, location, incident_date,
             reported_by, description, status, assigned_to, resolution_date, resolution_description) 
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *`,
            [incident_type, severity_level, location, incident_date, reported_by,
             description, status, assigned_to, resolution_date, resolution_description]
        );

        res.status(201).json(result.rows[0]);
    } catch (error) {
        console.error('Error creating emergency situation:', error);
        res.status(500).json({ message: 'Error creating emergency situation' });
    }
});

// Update emergency situation
router.put('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const {
            incident_type, severity_level, location, incident_date, reported_by,
            description, status, assigned_to, resolution_date, resolution_description
        } = req.body;

        const result = await pool.query(
            `UPDATE emergency_situations SET incident_type = $1, severity_level = $2, location = $3,
             incident_date = $4, reported_by = $5, description = $6, status = $7, assigned_to = $8,
             resolution_date = $9, resolution_description = $10, updated_at = CURRENT_TIMESTAMP 
             WHERE id = $11 RETURNING *`,
            [incident_type, severity_level, location, incident_date, reported_by,
             description, status, assigned_to, resolution_date, resolution_description, id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Emergency situation not found' });
        }

        res.json(result.rows[0]);
    } catch (error) {
        console.error('Error updating emergency situation:', error);
        res.status(500).json({ message: 'Error updating emergency situation' });
    }
});

// Delete emergency situation
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await pool.query('DELETE FROM emergency_situations WHERE id = $1 RETURNING *', [id]);

        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Emergency situation not found' });
        }

        res.json({ message: 'Emergency situation deleted successfully' });
    } catch (error) {
        console.error('Error deleting emergency situation:', error);
        res.status(500).json({ message: 'Error deleting emergency situation' });
    }
});

module.exports = router;