const express = require('express');
const router = express.Router();
const pool = require('../config/database');

// Get all pest control records
router.get('/', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM pest_control ORDER BY inspection_date DESC');
        res.json(result.rows);
    } catch (error) {
        console.error('Error fetching pest control records:', error);
        res.status(500).json({ message: 'Error fetching pest control records' });
    }
});

// Get pest control record by ID
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await pool.query('SELECT * FROM pest_control WHERE id = $1', [id]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Pest control record not found' });
        }
        
        res.json(result.rows[0]);
    } catch (error) {
        console.error('Error fetching pest control record:', error);
        res.status(500).json({ message: 'Error fetching pest control record' });
    }
});

// Create new pest control record
router.post('/', async (req, res) => {
    try {
        const {
            area, inspection_date, inspector_name, pest_type, severity_level,
            treatment_method, treatment_date, next_inspection, notes, status
        } = req.body;

        const result = await pool.query(
            `INSERT INTO pest_control (area, inspection_date, inspector_name, pest_type,
             severity_level, treatment_method, treatment_date, next_inspection, notes, status) 
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *`,
            [area, inspection_date, inspector_name, pest_type, severity_level,
             treatment_method, treatment_date, next_inspection, notes, status]
        );

        res.status(201).json(result.rows[0]);
    } catch (error) {
        console.error('Error creating pest control record:', error);
        res.status(500).json({ message: 'Error creating pest control record' });
    }
});

// Update pest control record
router.put('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const {
            area, inspection_date, inspector_name, pest_type, severity_level,
            treatment_method, treatment_date, next_inspection, notes, status
        } = req.body;

        const result = await pool.query(
            `UPDATE pest_control SET area = $1, inspection_date = $2, inspector_name = $3,
             pest_type = $4, severity_level = $5, treatment_method = $6, treatment_date = $7,
             next_inspection = $8, notes = $9, status = $10, updated_at = CURRENT_TIMESTAMP 
             WHERE id = $11 RETURNING *`,
            [area, inspection_date, inspector_name, pest_type, severity_level,
             treatment_method, treatment_date, next_inspection, notes, status, id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Pest control record not found' });
        }

        res.json(result.rows[0]);
    } catch (error) {
        console.error('Error updating pest control record:', error);
        res.status(500).json({ message: 'Error updating pest control record' });
    }
});

// Delete pest control record
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await pool.query('DELETE FROM pest_control WHERE id = $1 RETURNING *', [id]);

        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Pest control record not found' });
        }

        res.json({ message: 'Pest control record deleted successfully' });
    } catch (error) {
        console.error('Error deleting pest control record:', error);
        res.status(500).json({ message: 'Error deleting pest control record' });
    }
});

module.exports = router;