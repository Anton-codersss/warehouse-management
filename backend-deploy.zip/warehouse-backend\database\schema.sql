-- Database schema for Warehouse Management System

-- Create database (run this manually in PostgreSQL)
-- CREATE DATABASE warehouse_management;

-- Table for Warehouse Equipment (Складское Оборудование)
CREATE TABLE equipment (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(100) NOT NULL,
    model VARCHAR(100),
    serial_number VARCHAR(100) UNIQUE,
    status VARCHAR(50) DEFAULT 'active',
    location VARCHAR(255),
    maintenance_date DATE,
    next_maintenance DATE,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table for Warehouse Machinery (Складская Техника)
CREATE TABLE machinery (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(100) NOT NULL,
    brand VARCHAR(100),
    model VARCHAR(100),
    license_plate VARCHAR(50),
    status VARCHAR(50) DEFAULT 'operational',
    fuel_type VARCHAR(50),
    last_service DATE,
    next_service DATE,
    location VARCHAR(255),
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table for Pest Control (ПЕСТ контроль)
CREATE TABLE pest_control (
    id SERIAL PRIMARY KEY,
    area VARCHAR(255) NOT NULL,
    inspection_date DATE NOT NULL,
    inspector_name VARCHAR(255),
    pest_type VARCHAR(100),
    severity_level VARCHAR(50),
    treatment_method VARCHAR(255),
    treatment_date DATE,
    next_inspection DATE,
    notes TEXT,
    status VARCHAR(50) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table for Energy Resources (Энергоресурсы)
CREATE TABLE energy_resources (
    id SERIAL PRIMARY KEY,
    resource_type VARCHAR(100) NOT NULL, -- electricity, gas, water, etc.
    meter_number VARCHAR(100),
    location VARCHAR(255),
    current_reading DECIMAL(10,2),
    previous_reading DECIMAL(10,2),
    consumption DECIMAL(10,2),
    reading_date DATE,
    unit VARCHAR(20), -- kWh, m3, etc.
    cost_per_unit DECIMAL(10,2),
    total_cost DECIMAL(10,2),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table for Emergency Situations (Аварийные ситуации)
CREATE TABLE emergency_situations (
    id SERIAL PRIMARY KEY,
    incident_type VARCHAR(100) NOT NULL,
    severity_level VARCHAR(50) NOT NULL,
    location VARCHAR(255) NOT NULL,
    incident_date TIMESTAMP NOT NULL,
    reported_by VARCHAR(255),
    description TEXT NOT NULL,
    status VARCHAR(50) DEFAULT 'open',
    assigned_to VARCHAR(255),
    resolution_date TIMESTAMP,
    resolution_description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table for Works (Работы)
CREATE TABLE works (
    id SERIAL PRIMARY KEY,
    work_type VARCHAR(100) NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    priority VARCHAR(50) DEFAULT 'medium',
    status VARCHAR(50) DEFAULT 'planned',
    assigned_to VARCHAR(255),
    start_date DATE,
    end_date DATE,
    estimated_hours DECIMAL(5,2),
    actual_hours DECIMAL(5,2),
    location VARCHAR(255),
    equipment_involved TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table for Schemes (Схемы)
CREATE TABLE schemes (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(100) NOT NULL, -- layout, electrical, plumbing, etc.
    file_path VARCHAR(500),
    file_name VARCHAR(255),
    file_size INTEGER,
    description TEXT,
    version VARCHAR(20) DEFAULT '1.0',
    area VARCHAR(255),
    created_by VARCHAR(255),
    approved_by VARCHAR(255),
    approval_date DATE,
    status VARCHAR(50) DEFAULT 'draft',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table for Consumables (Расходные материалы)
CREATE TABLE consumables (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    category VARCHAR(100),
    unit VARCHAR(50) NOT NULL,
    current_stock DECIMAL(10,2) DEFAULT 0,
    min_stock_level DECIMAL(10,2) DEFAULT 0,
    max_stock_level DECIMAL(10,2),
    unit_cost DECIMAL(10,2),
    supplier VARCHAR(255),
    location VARCHAR(255),
    expiry_date DATE,
    description TEXT,
    status VARCHAR(50) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table for Secondary Materials (Вторичное сырье)
CREATE TABLE secondary_materials (
    id SERIAL PRIMARY KEY,
    material_type VARCHAR(100) NOT NULL,
    name VARCHAR(255) NOT NULL,
    quantity DECIMAL(10,2) NOT NULL,
    unit VARCHAR(50) NOT NULL,
    condition_status VARCHAR(100), -- good, fair, poor
    source VARCHAR(255),
    collection_date DATE,
    processing_status VARCHAR(50) DEFAULT 'collected',
    processing_date DATE,
    destination VARCHAR(255),
    estimated_value DECIMAL(10,2),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert sample data
INSERT INTO equipment (name, type, model, serial_number, status, location, description) VALUES
('Стеллаж № 1', 'Стеллажная система', 'SR-1000', 'STL001', 'active', 'Зона А1', 'Основной стеллаж для хранения'),
('Подъемник гидравлический', 'Подъемное оборудование', 'HL-500', 'HL001', 'active', 'Зона погрузки', 'Гидравлический подъемник 500кг'),
('Весы напольные', 'Измерительное оборудование', 'WS-1000', 'WS001', 'active', 'Приемка', 'Весы до 1000кг');

INSERT INTO machinery (name, type, brand, model, status, location, description) VALUES
('Погрузчик электрический', 'Складская техника', 'Toyota', '8FBE25', 'operational', 'Склад', 'Электрический погрузчик 2.5т'),
('Тележка гидравлическая', 'Ручная техника', 'Noblelift', 'PT2500', 'operational', 'Склад', 'Гидравлическая тележка 2.5т');

INSERT INTO consumables (name, category, unit, current_stock, min_stock_level, unit_cost, supplier, location) VALUES
('Стретч-пленка', 'Упаковочные материалы', 'рулон', 25, 10, 150.00, 'ООО "УпакПром"', 'Склад расходников'),
('Скотч упаковочный', 'Упаковочные материалы', 'шт', 50, 20, 35.00, 'ООО "УпакПром"', 'Склад расходников'),
('Масло гидравлическое', 'Технические жидкости', 'л', 100, 30, 250.00, 'ООО "ТехМасло"', 'Техническая зона');