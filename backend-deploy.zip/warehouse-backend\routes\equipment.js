const express = require('express');
const router = express.Router();
const pool = require('../config/database');
const { mockEquipment } = require('../data/mockData');

// In-memory storage for maintenance log when DB is not available
let maintenanceLogStorage = [
    {
        id: 1,
        repairDate: '2024-12-01',
        inventoryNumber: 'INV-001',
        equipmentType: 'Климатическое',
        equipmentName: 'Кондиционер промышленный',
        workType: 'ТО',
        performedWork: 'Замена фильтров, проверка системы охлаждения',
        manufacturer: 'Daikin',
        model: 'VRV-A',
        installationLocation: 'Зона А1',
        manufacturingDate: '2024-01-15',
        commissioningDate: '2024-02-01',
        workWarranty: '6 месяцев',
        performingOrganization: 'ООО "КлиматСервис"',
        cost: '25000',
        workActLink: 'АКТ-2024-001'
    },
    {
        id: 2,
        repairDate: '2024-11-15',
        inventoryNumber: 'INV-002',
        equipmentType: 'Подъёмное оборудование',
        equipmentName: 'Подъёмник гидравлический',
        workType: 'Ремонт',
        performedWork: 'Замена гидравлических шлангов, настройка системы',
        manufacturer: 'GENIE',
        model: 'GS-3246',
        installationLocation: 'Зона погрузки',
        manufacturingDate: '2024-02-10',
        commissioningDate: '2024-03-01',
        workWarranty: '12 месяцев',
        performingOrganization: 'ООО "ГидроСервис"',
        cost: '35000',
        workActLink: 'АКТ-2024-002'
    }
];

// ========== MAINTENANCE LOG ROUTES (должны быть ПЕРВЫМИ) ==========

// Get all maintenance log entries
router.get('/maintenance-log', async (req, res) => {
    try {
        // Try to get from database first
        const result = await pool.query(
            'SELECT * FROM maintenance_log ORDER BY repair_date DESC'
        );
        res.json(result.rows);
    } catch (error) {
        console.error('Database error, using in-memory storage:', error.message);
        // Use in-memory storage when database is not available
        res.json(maintenanceLogStorage);
    }
});

// Create new maintenance log entry
router.post('/maintenance-log', async (req, res) => {
    try {
        const {
            repairDate, inventoryNumber, equipmentType, equipmentName, workType,
            performedWork, manufacturer, model, installationLocation,
            manufacturingDate, commissioningDate, workWarranty,
            performingOrganization, cost, workActLink
        } = req.body;

        // Try to save to database first
        try {
            const result = await pool.query(
                `INSERT INTO maintenance_log 
                 (repair_date, inventory_number, equipment_type, equipment_name, work_type,
                  performed_work, manufacturer, model, installation_location,
                  manufacturing_date, commissioning_date, work_warranty,
                  performing_organization, cost, work_act_link) 
                 VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15) RETURNING *`,
                [repairDate, inventoryNumber, equipmentType, equipmentName, workType,
                 performedWork, manufacturer, model, installationLocation,
                 manufacturingDate, commissioningDate, workWarranty,
                 performingOrganization, cost, workActLink]
            );
            res.status(201).json(result.rows[0]);
        } catch (dbError) {
            console.error('Database error, saving to in-memory storage:', dbError.message);
            // Save to in-memory storage as fallback
            const newEntry = {
                id: maintenanceLogStorage.length + 1,
                repairDate, inventoryNumber, equipmentType, equipmentName, workType,
                performedWork, manufacturer, model, installationLocation,
                manufacturingDate, commissioningDate, workWarranty,
                performingOrganization, cost, workActLink
            };
            maintenanceLogStorage.push(newEntry);
            res.status(201).json(newEntry);
        }
    } catch (error) {
        console.error('Error creating maintenance log entry:', error);
        res.status(500).json({ message: 'Error creating maintenance log entry' });
    }
});

// Update maintenance log entry
router.put('/maintenance-log/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const {
            repairDate, inventoryNumber, equipmentType, equipmentName, workType,
            performedWork, manufacturer, model, installationLocation,
            manufacturingDate, commissioningDate, workWarranty,
            performingOrganization, cost, workActLink
        } = req.body;

        // Try to update in database first
        try {
            const result = await pool.query(
                `UPDATE maintenance_log SET 
                 repair_date = $1, inventory_number = $2, equipment_type = $3, equipment_name = $4,
                 work_type = $5, performed_work = $6, manufacturer = $7, model = $8,
                 installation_location = $9, manufacturing_date = $10, commissioning_date = $11,
                 work_warranty = $12, performing_organization = $13, cost = $14, work_act_link = $15,
                 updated_at = CURRENT_TIMESTAMP
                 WHERE id = $16 RETURNING *`,
                [repairDate, inventoryNumber, equipmentType, equipmentName, workType,
                 performedWork, manufacturer, model, installationLocation,
                 manufacturingDate, commissioningDate, workWarranty,
                 performingOrganization, cost, workActLink, id]
            );
            
            if (result.rows.length === 0) {
                return res.status(404).json({ message: 'Maintenance log entry not found' });
            }
            res.json(result.rows[0]);
        } catch (dbError) {
            console.error('Database error, updating in-memory storage:', dbError.message);
            // Update in-memory storage as fallback
            const entryIndex = maintenanceLogStorage.findIndex(entry => entry.id == id);
            if (entryIndex === -1) {
                return res.status(404).json({ message: 'Maintenance log entry not found' });
            }
            
            maintenanceLogStorage[entryIndex] = {
                ...maintenanceLogStorage[entryIndex],
                repairDate, inventoryNumber, equipmentType, equipmentName, workType,
                performedWork, manufacturer, model, installationLocation,
                manufacturingDate, commissioningDate, workWarranty,
                performingOrganization, cost, workActLink
            };
            res.json(maintenanceLogStorage[entryIndex]);
        }
    } catch (error) {
        console.error('Error updating maintenance log entry:', error);
        res.status(500).json({ message: 'Error updating maintenance log entry' });
    }
});

// Delete maintenance log entry
router.delete('/maintenance-log/:id', async (req, res) => {
    try {
        const { id } = req.params;
        
        // Try to delete from database first
        try {
            const result = await pool.query('DELETE FROM maintenance_log WHERE id = $1 RETURNING *', [id]);
            
            if (result.rows.length === 0) {
                return res.status(404).json({ message: 'Maintenance log entry not found' });
            }
            res.json({ message: 'Maintenance log entry deleted successfully' });
        } catch (dbError) {
            console.error('Database error, deleting from in-memory storage:', dbError.message);
            // Delete from in-memory storage as fallback
            const entryIndex = maintenanceLogStorage.findIndex(entry => entry.id == id);
            if (entryIndex === -1) {
                return res.status(404).json({ message: 'Maintenance log entry not found' });
            }
            
            maintenanceLogStorage.splice(entryIndex, 1);
            res.json({ message: 'Maintenance log entry deleted successfully' });
        }
    } catch (error) {
        console.error('Error deleting maintenance log entry:', error);
        res.status(500).json({ message: 'Error deleting maintenance log entry' });
    }
});

// ========== EQUIPMENT ROUTES ==========

// Get all equipment
router.get('/', async (req, res) => {
    try {
        const result = await pool.query(
            'SELECT * FROM equipment ORDER BY created_at DESC'
        );
        res.json(result.rows);
    } catch (error) {
        console.error('Database error, using mock data:', error.message);
        // Use mock data when database is not available
        res.json(mockEquipment);
    }
});

// Create new equipment
router.post('/', async (req, res) => {
    try {
        const {
            name, type, model, serial_number, status, location,
            maintenance_date, next_maintenance, description
        } = req.body;

        const result = await pool.query(
            `INSERT INTO equipment (name, type, model, serial_number, status, location, 
             maintenance_date, next_maintenance, description) 
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *`,
            [name, type, model, serial_number, status, location, 
             maintenance_date, next_maintenance, description]
        );

        res.status(201).json(result.rows[0]);
    } catch (error) {
        console.error('Error creating equipment:', error);
        res.status(500).json({ message: 'Error creating equipment' });
    }
});

// Get equipment by ID
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await pool.query('SELECT * FROM equipment WHERE id = $1', [id]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Equipment not found' });
        }
        
        res.json(result.rows[0]);
    } catch (error) {
        console.error('Error fetching equipment:', error);
        res.status(500).json({ message: 'Error fetching equipment' });
    }
});

// Update equipment
router.put('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const {
            name, type, model, serial_number, status, location,
            maintenance_date, next_maintenance, description
        } = req.body;

        const result = await pool.query(
            `UPDATE equipment SET name = $1, type = $2, model = $3, serial_number = $4,
             status = $5, location = $6, maintenance_date = $7, next_maintenance = $8,
             description = $9, updated_at = CURRENT_TIMESTAMP WHERE id = $10 RETURNING *`,
            [name, type, model, serial_number, status, location, 
             maintenance_date, next_maintenance, description, id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Equipment not found' });
        }

        res.json(result.rows[0]);
    } catch (error) {
        console.error('Error updating equipment:', error);
        res.status(500).json({ message: 'Error updating equipment' });
    }
});

// Delete equipment
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await pool.query('DELETE FROM equipment WHERE id = $1 RETURNING *', [id]);

        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Equipment not found' });
        }

        res.json({ message: 'Equipment deleted successfully' });
    } catch (error) {
        console.error('Error deleting equipment:', error);
        res.status(500).json({ message: 'Error deleting equipment' });
    }
});

module.exports = router;