const bcrypt = require('bcryptjs');

async function generatePasswords() {
  const passwords = [
    { username: 'admin', password: 'admin123' },
    { username: 'operator1', password: 'pass123' },
    { username: 'operator2', password: 'pass123' }
  ];

  for (const user of passwords) {
    const hash = await bcrypt.hash(user.password, 10);
    console.log(`${user.username}: ${hash}`);
  }
}

generatePasswords();