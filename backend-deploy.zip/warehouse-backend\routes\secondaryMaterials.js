const express = require('express');
const router = express.Router();
const pool = require('../config/database');

// Get all secondary materials
router.get('/', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM secondary_materials ORDER BY collection_date DESC');
        res.json(result.rows);
    } catch (error) {
        console.error('Error fetching secondary materials:', error);
        res.status(500).json({ message: 'Error fetching secondary materials' });
    }
});

// Get secondary material by ID
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await pool.query('SELECT * FROM secondary_materials WHERE id = $1', [id]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Secondary material not found' });
        }
        
        res.json(result.rows[0]);
    } catch (error) {
        console.error('Error fetching secondary material:', error);
        res.status(500).json({ message: 'Error fetching secondary material' });
    }
});

// Create new secondary material
router.post('/', async (req, res) => {
    try {
        const {
            material_type, name, quantity, unit, condition_status, source,
            collection_date, processing_status, processing_date, destination,
            estimated_value, notes
        } = req.body;

        const result = await pool.query(
            `INSERT INTO secondary_materials (material_type, name, quantity, unit, condition_status,
             source, collection_date, processing_status, processing_date, destination,
             estimated_value, notes) 
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12) RETURNING *`,
            [material_type, name, quantity, unit, condition_status, source,
             collection_date, processing_status, processing_date, destination,
             estimated_value, notes]
        );

        res.status(201).json(result.rows[0]);
    } catch (error) {
        console.error('Error creating secondary material:', error);
        res.status(500).json({ message: 'Error creating secondary material' });
    }
});

// Update secondary material
router.put('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const {
            material_type, name, quantity, unit, condition_status, source,
            collection_date, processing_status, processing_date, destination,
            estimated_value, notes
        } = req.body;

        const result = await pool.query(
            `UPDATE secondary_materials SET material_type = $1, name = $2, quantity = $3,
             unit = $4, condition_status = $5, source = $6, collection_date = $7,
             processing_status = $8, processing_date = $9, destination = $10,
             estimated_value = $11, notes = $12, updated_at = CURRENT_TIMESTAMP 
             WHERE id = $13 RETURNING *`,
            [material_type, name, quantity, unit, condition_status, source,
             collection_date, processing_status, processing_date, destination,
             estimated_value, notes, id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Secondary material not found' });
        }

        res.json(result.rows[0]);
    } catch (error) {
        console.error('Error updating secondary material:', error);
        res.status(500).json({ message: 'Error updating secondary material' });
    }
});

// Delete secondary material
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await pool.query('DELETE FROM secondary_materials WHERE id = $1 RETURNING *', [id]);

        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Secondary material not found' });
        }

        res.json({ message: 'Secondary material deleted successfully' });
    } catch (error) {
        console.error('Error deleting secondary material:', error);
        res.status(500).json({ message: 'Error deleting secondary material' });
    }
});

module.exports = router;