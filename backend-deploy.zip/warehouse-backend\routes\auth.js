const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const router = express.Router();

// Предустановленные пользователи для системы
const users = [
  {
    id: 1,
    username: 'admin',
    password: '$2b$10$GLMkuwyajfHuJNOVEE1hcOVG8tqiL/PC0mzEsUkskf04tuj23W0nq', // admin123
    role: 'admin',
    name: 'Администратор'
  },
  {
    id: 2,
    username: 'operator1',
    password: '$2b$10$AFeimImRiu7nzT3BAXeeje20JAe7vi.tvt3Nx3uFZXrHf8Swz6SjO', // pass123
    role: 'operator',
    name: 'Оператор 1'
  },
  {
    id: 3,
    username: 'operator2',
    password: '$2b$10$6nj4DnMRzrW2vtKVMyofDexNgGqNtAQQ1W.zl9ucgK.l.Y3Qd.q6W', // pass123
    role: 'operator',
    name: 'Оператор 2'
  }
];

// Секретный ключ для JWT
const JWT_SECRET = process.env.JWT_SECRET || 'warehouse-secret-key-2024';

// Вход в систему
router.post('/login', async (req, res) => {
  try {
    console.log('Login attempt:', { username: req.body.username });
    const { username, password } = req.body;

    if (!username || !password) {
      console.log('Login failed: missing credentials');
      return res.status(400).json({ 
        success: false, 
        message: 'Необходимо указать логин и пароль' 
      });
    }

    // Поиск пользователя
    const user = users.find(u => u.username === username);
    if (!user) {
      console.log('Login failed: user not found');
      return res.status(401).json({ 
        success: false, 
        message: 'Неверный логин или пароль' 
      });
    }

    // Проверка пароля
    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      console.log('Login failed: invalid password');
      return res.status(401).json({ 
        success: false, 
        message: 'Неверный логин или пароль' 
      });
    }

    // Создание JWT токена
    const token = jwt.sign(
      { 
        id: user.id, 
        username: user.username, 
        role: user.role 
      },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    console.log('Login successful for user:', username);
    res.json({
      success: true,
      message: 'Успешный вход в систему',
      token,
      user: {
        id: user.id,
        username: user.username,
        name: user.name,
        role: user.role
      }
    });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Ошибка сервера' 
    });
  }
});

// Проверка токена
router.get('/verify', (req, res) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    
    if (!token) {
      return res.status(401).json({ 
        success: false, 
        message: 'Токен не предоставлен' 
      });
    }

    const decoded = jwt.verify(token, JWT_SECRET);
    const user = users.find(u => u.id === decoded.id);
    
    if (!user) {
      return res.status(401).json({ 
        success: false, 
        message: 'Пользователь не найден' 
      });
    }

    res.json({
      success: true,
      user: {
        id: user.id,
        username: user.username,
        name: user.name,
        role: user.role
      }
    });

  } catch (error) {
    res.status(401).json({ 
      success: false, 
      message: 'Недействительный токен' 
    });
  }
});

// Выход из системы
router.post('/logout', (req, res) => {
  res.json({
    success: true,
    message: 'Успешный выход из системы'
  });
});

// Middleware для проверки аутентификации
const authenticateToken = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ 
      success: false, 
      message: 'Доступ запрещен. Необходима авторизация.' 
    });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    res.status(401).json({ 
      success: false, 
      message: 'Недействительный токен' 
    });
  }
};

module.exports = { router, authenticateToken };