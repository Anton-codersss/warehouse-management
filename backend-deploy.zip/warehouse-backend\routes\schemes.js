const express = require('express');
const router = express.Router();
const pool = require('../config/database');

// Get all schemes
router.get('/', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM schemes ORDER BY created_at DESC');
        res.json(result.rows);
    } catch (error) {
        console.error('Error fetching schemes:', error);
        res.status(500).json({ message: 'Error fetching schemes' });
    }
});

// Get scheme by ID
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await pool.query('SELECT * FROM schemes WHERE id = $1', [id]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Scheme not found' });
        }
        
        res.json(result.rows[0]);
    } catch (error) {
        console.error('Error fetching scheme:', error);
        res.status(500).json({ message: 'Error fetching scheme' });
    }
});

// Create new scheme
router.post('/', async (req, res) => {
    try {
        const {
            name, type, file_path, file_name, file_size, description, version,
            area, created_by, approved_by, approval_date, status
        } = req.body;

        const result = await pool.query(
            `INSERT INTO schemes (name, type, file_path, file_name, file_size, description,
             version, area, created_by, approved_by, approval_date, status) 
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12) RETURNING *`,
            [name, type, file_path, file_name, file_size, description, version,
             area, created_by, approved_by, approval_date, status]
        );

        res.status(201).json(result.rows[0]);
    } catch (error) {
        console.error('Error creating scheme:', error);
        res.status(500).json({ message: 'Error creating scheme' });
    }
});

// Update scheme
router.put('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const {
            name, type, file_path, file_name, file_size, description, version,
            area, created_by, approved_by, approval_date, status
        } = req.body;

        const result = await pool.query(
            `UPDATE schemes SET name = $1, type = $2, file_path = $3, file_name = $4,
             file_size = $5, description = $6, version = $7, area = $8, created_by = $9,
             approved_by = $10, approval_date = $11, status = $12, updated_at = CURRENT_TIMESTAMP 
             WHERE id = $13 RETURNING *`,
            [name, type, file_path, file_name, file_size, description, version,
             area, created_by, approved_by, approval_date, status, id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Scheme not found' });
        }

        res.json(result.rows[0]);
    } catch (error) {
        console.error('Error updating scheme:', error);
        res.status(500).json({ message: 'Error updating scheme' });
    }
});

// Delete scheme
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await pool.query('DELETE FROM schemes WHERE id = $1 RETURNING *', [id]);

        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Scheme not found' });
        }

        res.json({ message: 'Scheme deleted successfully' });
    } catch (error) {
        console.error('Error deleting scheme:', error);
        res.status(500).json({ message: 'Error deleting scheme' });
    }
});

module.exports = router;