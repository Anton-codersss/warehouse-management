const express = require('express');
const router = express.Router();
const pool = require('../config/database');
const { mockConsumables } = require('../data/mockData');

// Get all consumables
router.get('/', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM consumables ORDER BY name ASC');
        res.json(result.rows);
    } catch (error) {
        console.error('Database error, using mock data:', error.message);
        // Use mock data when database is not available
        res.json(mockConsumables);
    }
});

// Get consumable by ID
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await pool.query('SELECT * FROM consumables WHERE id = $1', [id]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Consumable not found' });
        }
        
        res.json(result.rows[0]);
    } catch (error) {
        console.error('Error fetching consumable:', error);
        res.status(500).json({ message: 'Error fetching consumable' });
    }
});

// Get low stock items
router.get('/low-stock', async (req, res) => {
    try {
        const result = await pool.query(
            'SELECT * FROM consumables WHERE current_stock <= min_stock_level ORDER BY name ASC'
        );
        res.json(result.rows);
    } catch (error) {
        console.error('Error fetching low stock items:', error);
        res.status(500).json({ message: 'Error fetching low stock items' });
    }
});

// Create new consumable
router.post('/', async (req, res) => {
    try {
        const {
            name, category, unit, current_stock, min_stock_level, max_stock_level,
            unit_cost, supplier, location, expiry_date, description, status
        } = req.body;

        const result = await pool.query(
            `INSERT INTO consumables (name, category, unit, current_stock, min_stock_level,
             max_stock_level, unit_cost, supplier, location, expiry_date, description, status) 
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12) RETURNING *`,
            [name, category, unit, current_stock, min_stock_level, max_stock_level,
             unit_cost, supplier, location, expiry_date, description, status]
        );

        res.status(201).json(result.rows[0]);
    } catch (error) {
        console.error('Error creating consumable:', error);
        res.status(500).json({ message: 'Error creating consumable' });
    }
});

// Update consumable
router.put('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const {
            name, category, unit, current_stock, min_stock_level, max_stock_level,
            unit_cost, supplier, location, expiry_date, description, status
        } = req.body;

        const result = await pool.query(
            `UPDATE consumables SET name = $1, category = $2, unit = $3, current_stock = $4,
             min_stock_level = $5, max_stock_level = $6, unit_cost = $7, supplier = $8,
             location = $9, expiry_date = $10, description = $11, status = $12,
             updated_at = CURRENT_TIMESTAMP WHERE id = $13 RETURNING *`,
            [name, category, unit, current_stock, min_stock_level, max_stock_level,
             unit_cost, supplier, location, expiry_date, description, status, id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Consumable not found' });
        }

        res.json(result.rows[0]);
    } catch (error) {
        console.error('Error updating consumable:', error);
        res.status(500).json({ message: 'Error updating consumable' });
    }
});

// Delete consumable
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await pool.query('DELETE FROM consumables WHERE id = $1 RETURNING *', [id]);

        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Consumable not found' });
        }

        res.json({ message: 'Consumable deleted successfully' });
    } catch (error) {
        console.error('Error deleting consumable:', error);
        res.status(500).json({ message: 'Error deleting consumable' });
    }
});

module.exports = router;