const express = require('express');
const router = express.Router();
const pool = require('../config/database');

// Get all works
router.get('/', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM works ORDER BY created_at DESC');
        res.json(result.rows);
    } catch (error) {
        console.error('Error fetching works:', error);
        res.status(500).json({ message: 'Error fetching works' });
    }
});

// Get work by ID
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await pool.query('SELECT * FROM works WHERE id = $1', [id]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Work not found' });
        }
        
        res.json(result.rows[0]);
    } catch (error) {
        console.error('Error fetching work:', error);
        res.status(500).json({ message: 'Error fetching work' });
    }
});

// Create new work
router.post('/', async (req, res) => {
    try {
        const {
            work_type, title, description, priority, status, assigned_to, start_date,
            end_date, estimated_hours, actual_hours, location, equipment_involved, notes
        } = req.body;

        const result = await pool.query(
            `INSERT INTO works (work_type, title, description, priority, status, assigned_to,
             start_date, end_date, estimated_hours, actual_hours, location, equipment_involved, notes) 
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13) RETURNING *`,
            [work_type, title, description, priority, status, assigned_to, start_date,
             end_date, estimated_hours, actual_hours, location, equipment_involved, notes]
        );

        res.status(201).json(result.rows[0]);
    } catch (error) {
        console.error('Error creating work:', error);
        res.status(500).json({ message: 'Error creating work' });
    }
});

// Update work
router.put('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const {
            work_type, title, description, priority, status, assigned_to, start_date,
            end_date, estimated_hours, actual_hours, location, equipment_involved, notes
        } = req.body;

        const result = await pool.query(
            `UPDATE works SET work_type = $1, title = $2, description = $3, priority = $4,
             status = $5, assigned_to = $6, start_date = $7, end_date = $8, estimated_hours = $9,
             actual_hours = $10, location = $11, equipment_involved = $12, notes = $13,
             updated_at = CURRENT_TIMESTAMP WHERE id = $14 RETURNING *`,
            [work_type, title, description, priority, status, assigned_to, start_date,
             end_date, estimated_hours, actual_hours, location, equipment_involved, notes, id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Work not found' });
        }

        res.json(result.rows[0]);
    } catch (error) {
        console.error('Error updating work:', error);
        res.status(500).json({ message: 'Error updating work' });
    }
});

// Delete work
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await pool.query('DELETE FROM works WHERE id = $1 RETURNING *', [id]);

        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Work not found' });
        }

        res.json({ message: 'Work deleted successfully' });
    } catch (error) {
        console.error('Error deleting work:', error);
        res.status(500).json({ message: 'Error deleting work' });
    }
});

module.exports = router;