// Mock data for demonstration when PostgreSQL is not available
const mockEquipment = [
  {
    id: 1,
    name: 'Стеллаж № 1',
    type: 'Стеллажная система',
    model: 'SR-1000',
    serial_number: 'STL001',
    status: 'active',
    location: 'Зона А1',
    maintenance_date: '2024-01-15',
    next_maintenance: '2024-07-15',
    description: 'Основной стеллаж для хранения',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: 2,
    name: 'Подъемник гидравлический',
    type: 'Подъемное оборудование',
    model: 'HL-500',
    serial_number: 'HL001',
    status: 'active',
    location: 'Зона погрузки',
    maintenance_date: '2024-02-01',
    next_maintenance: '2024-12-25', // Requires maintenance soon
    description: 'Гидравлический подъемник 500кг',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: 3,
    name: 'Весы напольные',
    type: 'Измерительное оборудование',
    model: 'WS-1000',
    serial_number: 'WS001',
    status: 'active',
    location: 'Приемка',
    maintenance_date: '2024-01-20',
    next_maintenance: '2024-10-20', // Requires maintenance soon
    description: 'Весы до 1000кг',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: 4,
    name: 'Стеллаж № 2',
    type: 'Стеллажная система',
    model: 'SR-2000',
    serial_number: 'STL002',
    status: 'maintenance',
    location: 'Зона Б1',
    maintenance_date: '2024-03-01',
    next_maintenance: '2024-09-01',
    description: 'Дополнительный стеллаж для хранения',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: 5,
    name: 'Подъемник электрический',
    type: 'Подъемное оборудование',
    model: 'EL-750',
    serial_number: 'EL001',
    status: 'inactive',
    location: 'Склад запчастей',
    maintenance_date: '2024-01-10',
    next_maintenance: '2024-07-10',
    description: 'Электрический подъемник 750кг (на ремонте)',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: 6,
    name: 'Весы торговые',
    type: 'Измерительное оборудование',
    model: 'TS-150',
    serial_number: 'TS001',
    status: 'active',
    location: 'Отгрузка',
    maintenance_date: '2024-02-15',
    next_maintenance: '2024-08-15',
    description: 'Торговые весы до 150кг',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
]

const mockMachinery = [
  {
    id: 1,
    name: 'Погрузчик электрический',
    type: 'Складская техника',
    brand: 'Toyota',
    model: '8FBE25',
    license_plate: 'С123АВ',
    status: 'operational',
    fuel_type: 'electric',
    last_service: '2024-01-10',
    next_service: '2024-04-10',
    location: 'Склад',
    description: 'Электрический погрузчик 2.5т',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: 2,
    name: 'Тележка гидравлическая',
    type: 'Ручная техника',
    brand: 'Noblelift',
    model: 'PT2500',
    license_plate: null,
    status: 'operational',
    fuel_type: 'manual',
    last_service: '2024-02-05',
    next_service: '2024-05-05',
    location: 'Склад',
    description: 'Гидравлическая тележка 2.5т',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
]

const mockConsumables = [
  {
    id: 1,
    name: 'Стретч-пленка',
    category: 'Упаковочные материалы',
    unit: 'рулон',
    current_stock: 25,
    min_stock_level: 10,
    max_stock_level: 50,
    unit_cost: 150.00,
    supplier: 'ООО "УпакПром"',
    location: 'Склад расходников',
    expiry_date: null,
    description: 'Прозрачная стретч-пленка для упаковки',
    status: 'active',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: 2,
    name: 'Скотч упаковочный',
    category: 'Упаковочные материалы',
    unit: 'шт',
    current_stock: 50,
    min_stock_level: 20,
    max_stock_level: 100,
    unit_cost: 35.00,
    supplier: 'ООО "УпакПром"',
    location: 'Склад расходников',
    expiry_date: null,
    description: 'Коричневый упаковочный скотч',
    status: 'active',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: 3,
    name: 'Масло гидравлическое',
    category: 'Технические жидкости',
    unit: 'л',
    current_stock: 100,
    min_stock_level: 30,
    max_stock_level: 200,
    unit_cost: 250.00,
    supplier: 'ООО "ТехМасло"',
    location: 'Техническая зона',
    expiry_date: '2025-12-31',
    description: 'Гидравлическое масло ISO VG 46',
    status: 'active',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
]

module.exports = {
  mockEquipment,
  mockMachinery,
  mockConsumables
}