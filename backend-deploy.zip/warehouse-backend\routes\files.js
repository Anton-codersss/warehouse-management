const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const router = express.Router();

// Create uploads directory if it doesn't exist
const uploadsDir = path.join(__dirname, '../uploads');
if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
}

// Configure multer for file uploads
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const { category = 'general', equipmentId = 'unknown' } = req.body;
        const uploadPath = path.join(uploadsDir, category, equipmentId);
        
        // Create directory if it doesn't exist
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        
        cb(null, uploadPath);
    },
    filename: function (req, file, cb) {
        // Generate unique filename with timestamp
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        const extension = path.extname(file.originalname);
        const baseName = path.basename(file.originalname, extension);
        cb(null, `${baseName}-${uniqueSuffix}${extension}`);
    }
});

// File filter for security
const fileFilter = (req, file, cb) => {
    // Allowed file types
    const allowedTypes = [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'image/jpeg',
        'image/jpg',
        'image/png',
        'image/gif',
        'image/webp',
        'text/plain'
    ];

    if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
    } else {
        cb(new Error(`Недопустимый тип файла: ${file.mimetype}. Разрешены только PDF, DOC, DOCX, XLS, XLSX, изображения и текстовые файлы.`), false);
    }
};

// Configure multer
const upload = multer({
    storage: storage,
    fileFilter: fileFilter,
    limits: {
        fileSize: 10 * 1024 * 1024, // 10MB limit
        files: 10 // Maximum 10 files at once
    }
});

// Upload multiple files
router.post('/upload', upload.array('files', 10), (req, res) => {
    try {
        if (!req.files || req.files.length === 0) {
            return res.status(400).json({ message: 'Не выбраны файлы для загрузки' });
        }

        const { category = 'general', equipmentId = 'unknown', description = '' } = req.body;

        const uploadedFiles = req.files.map(file => ({
            id: Date.now() + Math.random(),
            originalName: file.originalname,
            filename: file.filename,
            path: file.path,
            size: file.size,
            mimetype: file.mimetype,
            category: category,
            equipmentId: equipmentId,
            description: description,
            uploadedAt: new Date().toISOString()
        }));

        res.json({
            message: 'Файлы успешно загружены',
            files: uploadedFiles
        });

    } catch (error) {
        console.error('Error uploading files:', error);
        res.status(500).json({ message: 'Ошибка при загрузке файлов: ' + error.message });
    }
});

// Get file by filename
router.get('/download/:category/:equipmentId/:filename', (req, res) => {
    try {
        const { category, equipmentId, filename } = req.params;
        const filePath = path.join(uploadsDir, category, equipmentId, filename);

        if (!fs.existsSync(filePath)) {
            return res.status(404).json({ message: 'Файл не найден' });
        }

        res.download(filePath);
    } catch (error) {
        console.error('Error downloading file:', error);
        res.status(500).json({ message: 'Ошибка при скачивании файла' });
    }
});

// Get list of files for equipment
router.get('/list/:equipmentId', (req, res) => {
    try {
        const { equipmentId } = req.params;
        const equipmentUploadsDir = path.join(uploadsDir);
        const files = [];

        // Scan all categories for this equipment
        const categories = ['passport', 'instructions', 'certificates', 'photos', 'general'];
        
        categories.forEach(category => {
            const categoryPath = path.join(equipmentUploadsDir, category, equipmentId);
            if (fs.existsSync(categoryPath)) {
                const categoryFiles = fs.readdirSync(categoryPath);
                categoryFiles.forEach(filename => {
                    const filePath = path.join(categoryPath, filename);
                    const stats = fs.statSync(filePath);
                    files.push({
                        filename,
                        category,
                        size: stats.size,
                        uploadedAt: stats.ctime,
                        downloadUrl: `/api/files/download/${category}/${equipmentId}/${filename}`
                    });
                });
            }
        });

        res.json(files);
    } catch (error) {
        console.error('Error listing files:', error);
        res.status(500).json({ message: 'Ошибка при получении списка файлов' });
    }
});

// Delete file
router.delete('/delete/:category/:equipmentId/:filename', (req, res) => {
    try {
        const { category, equipmentId, filename } = req.params;
        const filePath = path.join(uploadsDir, category, equipmentId, filename);

        if (!fs.existsSync(filePath)) {
            return res.status(404).json({ message: 'Файл не найден' });
        }

        fs.unlinkSync(filePath);
        res.json({ message: 'Файл успешно удален' });
    } catch (error) {
        console.error('Error deleting file:', error);
        res.status(500).json({ message: 'Ошибка при удалении файла' });
    }
});

// Error handling middleware for multer
router.use((error, req, res, next) => {
    if (error instanceof multer.MulterError) {
        if (error.code === 'LIMIT_FILE_SIZE') {
            return res.status(400).json({ message: 'Размер файла превышает лимит в 10MB' });
        }
        if (error.code === 'LIMIT_FILE_COUNT') {
            return res.status(400).json({ message: 'Превышено максимальное количество файлов (10)' });
        }
    }
    
    if (error.message.includes('Недопустимый тип файла')) {
        return res.status(400).json({ message: error.message });
    }
    
    res.status(500).json({ message: 'Ошибка при обработке файлов' });
});

module.exports = router;